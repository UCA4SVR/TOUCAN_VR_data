function quality_mat=compute_Quality_AugExp(tileQuality,pickedTiles,headMotionFile,content,user,editing)

if strcmp(content,'Hotel')&& (strcmp(editing,'RS')|strcmp(editing,'RD')),
    fileSizes = importdata("../../data_for_exp/file_sizes_AugExp/hotel_random_file_sizes_formated.csv", ',', 1);
elseif strcmp(content,'Invisible')&& (strcmp(editing,'RS')|strcmp(editing,'RD')),
    fileSizes = importdata("../../data_for_exp/file_sizes_AugExp/invisible_random_file_sizes_formated.csv", ',', 1);
elseif strcmp(content,'Hotel')&& (strcmp(editing,'S')|strcmp(editing,'D')),
    fileSizes = importdata("../../data_for_exp/file_sizes_AugExp/hotel_static_file_sizes_formated.csv", ',', 1);
elseif strcmp(content,'Invisible')&& (strcmp(editing,'S')|strcmp(editing,'D')),
    fileSizes = importdata("../../data_for_exp/file_sizes_AugExp/invisible_static_file_sizes_formated.csv", ',', 1);
else
    error('wrong content or editing acronym');
end;
fileSizes = fileSizes.data;

headMotion = importdata(headMotionFile);

%% Compute the quality for the loaded files

startIndex = 1;
while size(headMotion(headMotion(:,1) <= pickedTiles(startIndex,1), [1,2]),1) == 0
    startIndex = startIndex+1;
end

nbHQ_FoV = [];
meansize_FoV = [];
for i=startIndex:size(pickedTiles,1)
    currentPickedTiles = pickedTiles(i,:);
    clockTime = currentPickedTiles(1);
    videoTime = headMotion(headMotion(:,1) <= clockTime, [1,2]);
    videoTime = videoTime(end, 2) + clockTime - videoTime(end,1);
    currentSegment=floor(videoTime/1000);
    currentQualities = tileQuality(tileQuality(:,3)==currentSegment, [2,6]);
    currentQualities = sortrows(currentQualities);
    if size(currentQualities,1)<9,
        continue;
    end;
    picked = currentPickedTiles(2:end);
    numberHighQuality = sum(picked(currentQualities(:,2)'>0));
    nbHQ_FoV = [nbHQ_FoV,numberHighQuality];
    meansize_FoV = [meansize_FoV,sum(picked)];
end
nbHQ_FoV=mean(nbHQ_FoV);
meansize_FoV=mean(meansize_FoV);

%% Compute total weight of each displayed segment in HQ
% sum of the weights of the tiles displayed
weight_displayedHQ = zeros(1,max(tileQuality(:,3)));
weight_displayedLQ = zeros(1,max(tileQuality(:,3)));

currentSegment = tileQuality(1,3);
currentQualities = tileQuality(tileQuality(:,3)==currentSegment, [2,6]);
currentQualities = sortrows(currentQualities);

while size(currentQualities,1) ~= 0
    currentWeightHQ = 0; currentWeightLQ = 0;
    for i = 1:9
        row = floor((i-1)/3);
        col = mod((i-1),3);
        currentFile = fileSizes(fileSizes(:,2)==currentSegment,1:end);
        currentFile = currentFile(currentFile(:,3)==col,1:end);
        currentFile = currentFile(currentFile(:,4)==row,1:end);
        currentFile = currentFile(currentFile(:,1)==currentQualities(i,2),1:end);
        if currentQualities(i,2)==1
            currentWeightHQ = currentWeightHQ + currentFile(5);
        else,
            currentWeightLQ = currentWeightLQ + currentFile(5);
        end
    end
    if sum(currentQualities(:,2)==1)>0, weight_displayedHQ(currentSegment) = currentWeightHQ/sum(currentQualities(:,2)==1); end;
    if sum(currentQualities(:,2)==0)>0, weight_displayedLQ(currentSegment) = currentWeightLQ/sum(currentQualities(:,2)==0); end;
    
    currentSegment = currentSegment+1;
    currentQualities = tileQuality(tileQuality(:,3)==currentSegment, [2,6]);
    %%% to complete when pb with diff nb of segements per tile
    l=size(currentQualities,1);
    if l>0 && l<9,
        l=size(currentQualities,1); currentQualities(l+1:9,:)=[(setdiff(0:8,currentQualities(:,1)))',zeros(length(l:8),1)];
    end;
    %%%
    currentQualities = sortrows(currentQualities);
end
Weight_dispHQ=mean(weight_displayedHQ(weight_displayedHQ>0));
Weight_dispLQ=mean(weight_displayedLQ(weight_displayedLQ>0));
quality_mat=[nbHQ_FoV;meansize_FoV;Weight_dispHQ;Weight_dispLQ];