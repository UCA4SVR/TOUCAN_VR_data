%% Script to post-process the users' data from Aug. 2017 experiments (i.e., set 1 of experiments) and plot corresponding figures
%% Pairwise tests have been run between the different proposed editings:
%% Random Static (RS) vs. Static (S)
%% Random Dynamic (RD) vs. Dynamic (D)
%% Static (S) vs. Dynamic (D)

clear
clc
close all
%%{
directory_name = '../../data_from_exp/LogFiles_AugExp/';


Hotel_RS_S_RS_userind=[2,4,8,12];
Hotel_RS_S_S_userind=[102,104,108,112];

Hotel_S_D_S_userind=[7,9,10,11];
Hotel_S_D_D_userind=[107,109,110,111];

Hotel_RD_D_RD_userind=[3,6,13,16];
Hotel_RD_D_D_userind=[103,106,113,116];

Invisible_RS_S_RS_userind=[1,5,15,17];
Invisible_RS_S_S_userind=[101,105,115,117];

Invisible_S_D_S_userind=[14,18,19,21];
Invisible_S_D_D_userind=[114,118,119,121];

Invisible_RD_D_RD_userind=[120,22,23,24];
Invisible_RD_D_D_userind=[20,122,123,124];

exp_reg={Hotel_RS_S_RS_userind,Hotel_RS_S_S_userind,Hotel_S_D_S_userind,Hotel_S_D_D_userind,Hotel_RD_D_RD_userind,Hotel_RD_D_D_userind,...
    Invisible_RS_S_RS_userind,Invisible_RS_S_S_userind,Invisible_S_D_S_userind,Invisible_S_D_D_userind,Invisible_RD_D_RD_userind,Invisible_RD_D_D_userind};
%%{
indexes_HOTEL_RS_S_RS=[]; indexes_HOTEL_RS_S_S=[]; indexes_HOTEL_S_D_S=[]; indexes_HOTEL_S_D_D=[]; indexes_HOTEL_RD_D_RD=[]; indexes_HOTEL_RD_D_D=[];
indexes_INVISIBLE_RS_S_RS=[]; indexes_INVISIBLE_RS_S_S=[]; indexes_INVISIBLE_S_D_S=[]; indexes_INVISIBLE_S_D_D=[]; indexes_INVISIBLE_RD_D_RD=[]; indexes_INVISIBLE_RD_D_D=[];
allBW=cell(1,size(exp_reg,2)); allHM=cell(1,size(exp_reg,2)); allRPL=cell(1,size(exp_reg,2)); allDBW=cell(1,size(exp_reg,2)); allQUAL=cell(1,size(exp_reg,2));
for class_exp_ind = 1:size(exp_reg,2)
    if class_exp_ind <=6,
        content='Hotel';
    else,
        content='Invisible';
    end;
    if class_exp_ind==1||class_exp_ind==7,
        editing='RS';
    elseif class_exp_ind==2||class_exp_ind==3||class_exp_ind==8||class_exp_ind==9,
        editing='S';
    elseif class_exp_ind==4||class_exp_ind==6||class_exp_ind==10||class_exp_ind==12,
        editing='D';
    elseif class_exp_ind==5||class_exp_ind==11,
        editing='RD';
    end;
    
    users_ind=cell2mat(exp_reg(class_exp_ind));
    bw_users_exp=[]; rpl_users_exp=[]; hm_users_exp=[]; dispbw_users_exp=[]; quality_users_exp=[];
    for user_ind=1:length(users_ind),
        % get the headMotion file
        path=[directory_name,'User ',num2str(users_ind(user_ind))];
        files = dir(path);
        fileIndex = find(~[files.isdir]);
        for i = 1:length(fileIndex),
            fileName = files(fileIndex(i)).name;
            if contains(fileName,'headMotion')
                headMotionFile=fileName;
            elseif contains(fileName,'repl')
                replacementsFile=fileName;
            elseif contains(fileName,'bandwidth')
                bandwidthFile=fileName;
            elseif contains(fileName,'Qual')
                tileQualityFile=fileName;
            elseif contains(fileName,'picked')
                pickedTilesFile=fileName;
            end
        end
        %%% To filter out initial and final stages (user puts on or removes HMD)
        time_start=5; % in sec
        if strcmp(content,'Hotel'),
            time_end=120;
        elseif strcmp(content,'Invisible'),
            time_end=300;
        end
        % compute the quantities
        bw_user = csvread([path,'/',bandwidthFile]);
        ind_start=find(bw_user(:,2)-bw_user(1,2)>=time_start*10^3); ind_start=ind_start(1);
        ind_end=find(bw_user(:,2)-bw_user(1,2)>=time_end*10^3); if ~isempty(ind_end), ind_end=ind_end(1); else, ind_end=size(bw_user,1); end;
        bw_users_exp= [bw_users_exp,(bw_user(ind_end,3))/10^6];
        rpl_user = csvread([path,'/',replacementsFile]);
        ind_start=find(rpl_user(:,1)-bw_user(1,2)>=time_start*10^3); if ~isempty(ind_start), ind_start=ind_start(1); else, ind_start=1; end;
        rpl_user=rpl_user(ind_start:end,:);
        ind_end=find(rpl_user(:,1)-bw_user(1,2)>=time_end*10^3); if ~isempty(ind_end), ind_end=ind_end(1); else, ind_end=size(rpl_user,1); end;
        rpl_user=rpl_user(1:ind_end,:);
        rpl_users_exp= [rpl_users_exp,length(rpl_user(:,1))];
        
        tilequal= csvread([path,'/',tileQualityFile]);
        ind_start=find(tilequal(:,1)-bw_user(1,2)>=time_start*10^3); ind_start=ind_start(1);
        ind_end=find(tilequal(:,1)-bw_user(1,2)>=time_end*10^3); if ~isempty(ind_end), ind_end=ind_end(1); else, ind_end=size(tilequal,1); end;
        ind_seg_start=tilequal(ind_start,3);
        ind_seg_end=tilequal(ind_end,3);
        tilequal=tilequal(tilequal(:,3)>=ind_seg_start,:);
        tilequal=tilequal(tilequal(:,3)<=ind_seg_end,:);
        dispbw_user=compute_DisplayedBw_AugExp(tilequal,content,editing);
        dispbw_users_exp = [dispbw_users_exp, dispbw_user];
    
        pickedtiles= csvread([path,'/',pickedTilesFile]);
        ind_start=find(pickedtiles(:,1)-bw_user(1,2)>=time_start*10^3); ind_start=ind_start(1);
        ind_end=find(pickedtiles(:,1)-bw_user(1,2)>=time_end*10^3); if ~isempty(ind_end), ind_end=ind_end(1); else, ind_end=size(pickedtiles,1); end;
        pickedtiles=pickedtiles(ind_start:ind_end,:);
        quality_user=compute_Quality_AugExp(tilequal,pickedtiles,[path,'/',headMotionFile],content,users_ind(user_ind),editing);
        quality_users_exp=[quality_users_exp,quality_user];
        
        %%% Head motion: computes time series, detect then correct abnormalities (i.e., jumps from -180° to +180° corresponding to smooth motion)
        % This command may require setting the absolute path
        system(['python3 ../DataVisualization/headprocess_AugExp.py -w 53 -d 200 -i "',path,'/',headMotionFile,'" -u ',num2str(users_ind(user_ind)),' -e "',editing,'"']);
        load([path,'/user',num2str(users_ind(user_ind)),'_',editing,'_hm.mat']);
        ind_start=find(headMotion_time>=time_start); ind_start=ind_start(1);
        ind_end=find(headMotion_time>=time_end); if ~isempty(ind_end), ind_end=ind_end(1); else, ind_end=length(headMotion_time); end;
        
        headMotion_meanVelocity=headMotion_meanVelocity(ind_start:ind_end);
        headMotion_velocityX=headMotion_velocityX(ind_start:ind_end);
        headMotion_velocityY=headMotion_velocityY(ind_start:ind_end);
        headMotion_positionX=headMotion_positionX(ind_start:ind_end);
        headMotion_positionY=headMotion_positionY(ind_start:ind_end);
        headMotion_time=headMotion_time(ind_start:ind_end);
        %%% Check sanity of the head motion data
        if sum(abs(headMotion_velocityX)>700)+sum(abs(headMotion_velocityY)>700)>0,
            system(['python3 ../DataVisualization/headprocess_AugExp.py -w 20 -i "',path,'/',headMotionFile,'" -u ',num2str(users_ind(user_ind)),' -e "',editing,'"']);
            load([path,'/user',num2str(users_ind(user_ind)),'_',editing,'_hm.mat']);
            ind_start=find(headMotion_time>=time_start); ind_start=ind_start(1);
            ind_end=find(headMotion_time>=time_end); if ~isempty(ind_end), ind_end=ind_end(1); else, ind_end=length(headMotion_time); end;
            headMotion_meanVelocity=headMotion_meanVelocity(ind_start:ind_end);
            
            headMotion_velocityX=headMotion_velocityX(ind_start:ind_end);
            headMotion_velocityY=headMotion_velocityY(ind_start:ind_end);
            headMotion_positionX=headMotion_positionX(ind_start:ind_end);
            headMotion_positionY=headMotion_positionY(ind_start:ind_end);
            headMotion_time=headMotion_time(ind_start:ind_end);
        end;
        hm_user = headMotion_meanVelocity;
        hm_users_exp= [hm_users_exp,hm_user(end)];
    end
    allBW{class_exp_ind}=bw_users_exp; allHM{class_exp_ind}=hm_users_exp; allRPL{class_exp_ind}=rpl_users_exp; 
    allDBW{class_exp_ind}=dispbw_users_exp; allQUAL{class_exp_ind}=quality_users_exp; 
end
%}

%% Getting the parameters for the FoV size
classind_Hotel_RS_S_RS=1; classind_Hotel_RS_S_S=2; classind_Hotel_S_D_S=3; classind_Hotel_S_D_D=4; classind_Hotel_RD_D_RD=5; classind_Hotel_RD_D_D=6;
classind_Invisible_RS_S_RS=7; classind_Invisible_RS_S_S=8; classind_Invisible_S_D_S=9; classind_Invisible_S_D_D=10; classind_Invisible_RD_D_RD=11; classind_Invisible_RD_D_D=12;

meanqual_Hotel_RS_S_RS= mean(cell2mat(allQUAL(classind_Hotel_RS_S_RS)),2); FoVsize_Hotel_RS_S_RS=meanqual_Hotel_RS_S_RS(2,1);
meanqual_Hotel_RS_S_S= mean(cell2mat(allQUAL(classind_Hotel_RS_S_S)),2); FoVsize_Hotel_RS_S_S=meanqual_Hotel_RS_S_S(2,1);
meanqual_Hotel_S_D_S= mean(cell2mat(allQUAL(classind_Hotel_S_D_S)),2); FoVsize_Hotel_S_D_S=meanqual_Hotel_S_D_S(2,1);
FoVsize_Hotel_S=mean([FoVsize_Hotel_RS_S_RS,FoVsize_Hotel_RS_S_S,FoVsize_Hotel_S_D_S]);

meanqual_Invisible_RS_S_RS= mean(cell2mat(allQUAL(classind_Invisible_RS_S_RS)),2); FoVsize_Invisible_RS_S_RS=meanqual_Invisible_RS_S_RS(2,1);
meanqual_Invisible_RS_S_S= mean(cell2mat(allQUAL(classind_Invisible_RS_S_S)),2); FoVsize_Invisible_RS_S_S=meanqual_Invisible_RS_S_S(2,1);
meanqual_Invisible_S_D_S= mean(cell2mat(allQUAL(classind_Invisible_S_D_S)),2); FoVsize_Invisible_S_D_S=meanqual_Invisible_S_D_S(2,1);
FoVsize_Invisible_S=mean([FoVsize_Invisible_RS_S_RS,FoVsize_Invisible_RS_S_S,FoVsize_Invisible_S_D_S]);

%%% FoV size computation for dynamic editing
% The tile picker has drifted with snap-changes, and has increased the
% number of tiles in the FoV (size of FoVs above). This will be fixed in the next TOUCAN-VR
% version. The below lines are meant to correct the FoV size of dynamic.
% nb of segments given by the time boundaries, given 1 seg is 1 sec
meanqual_Hotel_RD_D_RD= mean(cell2mat(allQUAL(classind_Hotel_RD_D_RD)),2); 
FoVsize_Hotel_RD_D_RD=meanqual_Hotel_RD_D_RD(2,1); 
meanweightHQ_Hotel_RD_D_RD=meanqual_Hotel_RD_D_RD(3,1);
meanweightLQ_Hotel_RD_D_RD=meanqual_Hotel_RD_D_RD(4,1);
bwtocut=1/10^6*(time_end-time_start)*(FoVsize_Hotel_RD_D_RD-FoVsize_Hotel_S)*(meanweightHQ_Hotel_RD_D_RD-meanweightLQ_Hotel_RD_D_RD);
allBW{classind_Hotel_RD_D_RD}=allBW{classind_Hotel_RD_D_RD}-bwtocut;
allDBW{classind_Hotel_RD_D_RD}=allDBW{classind_Hotel_RD_D_RD}-bwtocut;
temp=allQUAL{classind_Hotel_RD_D_RD}; temp(1,:)=temp(1,:)/FoVsize_Hotel_RD_D_RD; allQUAL{classind_Hotel_RD_D_RD}=temp;

meanqual_Hotel_RD_D_D= mean(cell2mat(allQUAL(classind_Hotel_RD_D_D)),2); 
FoVsize_Hotel_RD_D_D=meanqual_Hotel_RD_D_D(2,1); 
meanweightHQ_Hotel_RD_D_D=meanqual_Hotel_RD_D_D(3,1);
meanweightLQ_Hotel_RD_D_D=meanqual_Hotel_RD_D_D(4,1);
bwtocut=1/10^6*(time_end-time_start)*(FoVsize_Hotel_RD_D_D-FoVsize_Hotel_S)*(meanweightHQ_Hotel_RD_D_D-meanweightLQ_Hotel_RD_D_D);
allBW{classind_Hotel_RD_D_D}=allBW{classind_Hotel_RD_D_D}-bwtocut;
allDBW{classind_Hotel_RD_D_D}=allDBW{classind_Hotel_RD_D_D}-bwtocut;
temp=allQUAL{classind_Hotel_RD_D_D}; temp(1,:)=temp(1,:)/FoVsize_Hotel_RD_D_D; allQUAL{classind_Hotel_RD_D_D}=temp;

meanqual_Hotel_S_D_D= mean(cell2mat(allQUAL(classind_Hotel_S_D_D)),2); 
FoVsize_Hotel_S_D_D=meanqual_Hotel_S_D_D(2,1); 
meanweightHQ_Hotel_S_D_D=meanqual_Hotel_S_D_D(3,1);
meanweightLQ_Hotel_S_D_D=meanqual_Hotel_S_D_D(4,1);
bwtocut=1/10^6*(time_end-time_start)*(FoVsize_Hotel_S_D_D-FoVsize_Hotel_S)*(meanweightHQ_Hotel_S_D_D-meanweightLQ_Hotel_S_D_D);
allBW{classind_Hotel_S_D_D}=allBW{classind_Hotel_S_D_D}-bwtocut;
allDBW{classind_Hotel_S_D_D}=allDBW{classind_Hotel_S_D_D}-bwtocut;
temp=allQUAL{classind_Hotel_S_D_D}; temp(1,:)=temp(1,:)/FoVsize_Hotel_S_D_D; allQUAL{classind_Hotel_S_D_D}=temp;

temp=allQUAL{classind_Hotel_RS_S_RS}; temp(1,:)=temp(1,:)/FoVsize_Hotel_RS_S_RS; allQUAL{classind_Hotel_RS_S_RS}=temp;
temp=allQUAL{classind_Hotel_RS_S_S}; temp(1,:)=temp(1,:)/FoVsize_Hotel_RS_S_S; allQUAL{classind_Hotel_RS_S_S}=temp;
temp=allQUAL{classind_Hotel_S_D_S}; temp(1,:)=temp(1,:)/FoVsize_Hotel_S_D_S; allQUAL{classind_Hotel_S_D_S}=temp;

meanqual_Invisible_RD_D_RD= mean(cell2mat(allQUAL(classind_Invisible_RD_D_RD)),2); 
FoVsize_Invisible_RD_D_RD=meanqual_Invisible_RD_D_RD(2,1); 
meanweightHQ_Invisible_RD_D_RD=meanqual_Invisible_RD_D_RD(3,1);
meanweightLQ_Invisible_RD_D_RD=meanqual_Invisible_RD_D_RD(4,1);
bwtocut=1/10^6*(time_end-time_start)*(FoVsize_Invisible_RD_D_RD-FoVsize_Invisible_S)*(meanweightHQ_Invisible_RD_D_RD-meanweightLQ_Invisible_RD_D_RD);
allBW{classind_Invisible_RD_D_RD}=allBW{classind_Invisible_RD_D_RD}-bwtocut;
allDBW{classind_Invisible_RD_D_RD}=allDBW{classind_Invisible_RD_D_RD}-bwtocut;
temp=allQUAL{classind_Invisible_RD_D_RD}; temp(1,:)=temp(1,:)/FoVsize_Invisible_RD_D_RD; allQUAL{classind_Invisible_RD_D_RD}=temp;

meanqual_Invisible_RD_D_D= mean(cell2mat(allQUAL(classind_Invisible_RD_D_D)),2); 
FoVsize_Invisible_RD_D_D=meanqual_Invisible_RD_D_D(2,1); 
meanweightHQ_Invisible_RD_D_D=meanqual_Invisible_RD_D_D(3,1);
meanweightLQ_Invisible_RD_D_D=meanqual_Invisible_RD_D_D(4,1);
bwtocut=1/10^6*(time_end-time_start)*(FoVsize_Invisible_RD_D_D-FoVsize_Invisible_S)*(meanweightHQ_Invisible_RD_D_D-meanweightLQ_Invisible_RD_D_D);
allBW{classind_Invisible_RD_D_D}=allBW{classind_Invisible_RD_D_D}-bwtocut;
allDBW{classind_Invisible_RD_D_D}=allDBW{classind_Invisible_RD_D_D}-bwtocut;
temp=allQUAL{classind_Invisible_RD_D_D}; temp(1,:)=temp(1,:)/FoVsize_Invisible_RD_D_D; allQUAL{classind_Invisible_RD_D_D}=temp;

meanqual_Invisible_S_D_D= mean(cell2mat(allQUAL(classind_Invisible_S_D_D)),2); 
FoVsize_Invisible_S_D_D=meanqual_Invisible_S_D_D(2,1); 
meanweightHQ_Invisible_S_D_D=meanqual_Invisible_S_D_D(3,1);
meanweightLQ_Invisible_S_D_D=meanqual_Invisible_S_D_D(4,1);
bwtocut=1/10^6*(time_end-time_start)*(FoVsize_Invisible_S_D_D-FoVsize_Invisible_S)*(meanweightHQ_Invisible_S_D_D-meanweightLQ_Invisible_S_D_D);
allBW{classind_Invisible_S_D_D}=allBW{classind_Invisible_S_D_D}-bwtocut;
allDBW{classind_Invisible_S_D_D}=allDBW{classind_Invisible_S_D_D}-bwtocut;
temp=allQUAL{classind_Invisible_S_D_D}; temp(1,:)=temp(1,:)/FoVsize_Invisible_S_D_D; allQUAL{classind_Invisible_S_D_D}=temp;

temp=allQUAL{classind_Invisible_RS_S_RS}; temp(1,:)=temp(1,:)/FoVsize_Invisible_RS_S_RS; allQUAL{classind_Invisible_RS_S_RS}=temp;
temp=allQUAL{classind_Invisible_RS_S_S}; temp(1,:)=temp(1,:)/FoVsize_Invisible_RS_S_S; allQUAL{classind_Invisible_RS_S_S}=temp;
temp=allQUAL{classind_Invisible_S_D_S}; temp(1,:)=temp(1,:)/FoVsize_Invisible_S_D_S; allQUAL{classind_Invisible_S_D_S}=temp;

%% Final quantities
indexes_Hotel_RS_S_RS=1; indexes_Hotel_RS_S_S=2; indexes_Hotel_S_D_S=3; indexes_Hotel_S_D_D=4; indexes_Hotel_RD_D_RD=5; indexes_Hotel_RD_D_D=6; 
indexes_Invisible_RS_S_RS=7; indexes_Invisible_RS_S_S=8; indexes_Invisible_S_D_S=9; indexes_Invisible_S_D_D=10; indexes_Invisible_RD_D_RD=11; indexes_Invisible_RD_D_D=12; 

HeadMotion_Hotel_RS_S_RS = cell2mat(allHM(indexes_Hotel_RS_S_RS));
HeadMotion_Hotel_RS_S_S = cell2mat(allHM(indexes_Hotel_RS_S_S));
HeadMotion_Hotel_S_D_S = cell2mat(allHM(indexes_Hotel_S_D_S));
HeadMotion_Hotel_S_D_D = cell2mat(allHM(indexes_Hotel_S_D_D));
HeadMotion_Hotel_RD_D_RD = cell2mat(allHM(indexes_Hotel_RD_D_RD));
HeadMotion_Hotel_RD_D_D = cell2mat(allHM(indexes_Hotel_RD_D_D));
HeadMotion_Invisible_RS_S_RS = cell2mat(allHM(indexes_Invisible_RS_S_RS));
HeadMotion_Invisible_RS_S_S = cell2mat(allHM(indexes_Invisible_RS_S_S));
HeadMotion_Invisible_S_D_S = cell2mat(allHM(indexes_Invisible_S_D_S));
HeadMotion_Invisible_S_D_D = cell2mat(allHM(indexes_Invisible_S_D_D));
HeadMotion_Invisible_RD_D_RD = cell2mat(allHM(indexes_Invisible_RD_D_RD));
HeadMotion_Invisible_RD_D_D = cell2mat(allHM(indexes_Invisible_RD_D_D));

Bandwidth_Hotel_RS_S_RS = cell2mat(allBW(indexes_Hotel_RS_S_RS));
Bandwidth_Hotel_RS_S_S = cell2mat(allBW(indexes_Hotel_RS_S_S));
Bandwidth_Hotel_S_D_S = cell2mat(allBW(indexes_Hotel_S_D_S));
Bandwidth_Hotel_S_D_D = cell2mat(allBW(indexes_Hotel_S_D_D));
Bandwidth_Hotel_RD_D_RD = cell2mat(allBW(indexes_Hotel_RD_D_RD));
Bandwidth_Hotel_RD_D_D = cell2mat(allBW(indexes_Hotel_RD_D_D));
Bandwidth_Invisible_RS_S_RS = cell2mat(allBW(indexes_Invisible_RS_S_RS));
Bandwidth_Invisible_RS_S_S = cell2mat(allBW(indexes_Invisible_RS_S_S));
Bandwidth_Invisible_S_D_S = cell2mat(allBW(indexes_Invisible_S_D_S));
Bandwidth_Invisible_S_D_D = cell2mat(allBW(indexes_Invisible_S_D_D));
Bandwidth_Invisible_RD_D_RD = cell2mat(allBW(indexes_Invisible_RD_D_RD));
Bandwidth_Invisible_RD_D_D = cell2mat(allBW(indexes_Invisible_RD_D_D));

Replacements_Hotel_RS_S_RS = cell2mat(allRPL(indexes_Hotel_RS_S_RS));
Replacements_Hotel_RS_S_S = cell2mat(allRPL(indexes_Hotel_RS_S_S));
Replacements_Hotel_S_D_S = cell2mat(allRPL(indexes_Hotel_S_D_S));
Replacements_Hotel_S_D_D = cell2mat(allRPL(indexes_Hotel_S_D_D));
Replacements_Hotel_RD_D_RD = cell2mat(allRPL(indexes_Hotel_RD_D_RD));
Replacements_Hotel_RD_D_D = cell2mat(allRPL(indexes_Hotel_RD_D_D));
Replacements_Invisible_RS_S_RS = cell2mat(allRPL(indexes_Invisible_RS_S_RS));
Replacements_Invisible_RS_S_S = cell2mat(allRPL(indexes_Invisible_RS_S_S));
Replacements_Invisible_S_D_S = cell2mat(allRPL(indexes_Invisible_S_D_S));
Replacements_Invisible_S_D_D = cell2mat(allRPL(indexes_Invisible_S_D_D));
Replacements_Invisible_RD_D_RD = cell2mat(allRPL(indexes_Invisible_RD_D_RD));
Replacements_Invisible_RD_D_D = cell2mat(allRPL(indexes_Invisible_RD_D_D));

DisplayedBandwidth_Hotel_RS_S_RS = cell2mat(allDBW(indexes_Hotel_RS_S_RS));
DisplayedBandwidth_Hotel_RS_S_S = cell2mat(allDBW(indexes_Hotel_RS_S_S));
DisplayedBandwidth_Hotel_S_D_S = cell2mat(allDBW(indexes_Hotel_S_D_S));
DisplayedBandwidth_Hotel_S_D_D = cell2mat(allDBW(indexes_Hotel_S_D_D));
DisplayedBandwidth_Hotel_RD_D_RD = cell2mat(allDBW(indexes_Hotel_RD_D_RD));
DisplayedBandwidth_Hotel_RD_D_D = cell2mat(allDBW(indexes_Hotel_RD_D_D));
DisplayedBandwidth_Invisible_RS_S_RS = cell2mat(allDBW(indexes_Invisible_RS_S_RS));
DisplayedBandwidth_Invisible_RS_S_S = cell2mat(allDBW(indexes_Invisible_RS_S_S));
DisplayedBandwidth_Invisible_S_D_S = cell2mat(allDBW(indexes_Invisible_S_D_S));
DisplayedBandwidth_Invisible_S_D_D = cell2mat(allDBW(indexes_Invisible_S_D_D));
DisplayedBandwidth_Invisible_RD_D_RD = cell2mat(allDBW(indexes_Invisible_RD_D_RD));
DisplayedBandwidth_Invisible_RD_D_D = cell2mat(allDBW(indexes_Invisible_RD_D_D));

WastedBandwidth_Hotel_RS_S_RS = Bandwidth_Hotel_RS_S_RS-DisplayedBandwidth_Hotel_RS_S_RS;
WastedBandwidth_Hotel_RS_S_S = Bandwidth_Hotel_RS_S_S-DisplayedBandwidth_Hotel_RS_S_S;
WastedBandwidth_Hotel_S_D_S = Bandwidth_Hotel_S_D_S-DisplayedBandwidth_Hotel_S_D_S;
WastedBandwidth_Hotel_S_D_D = Bandwidth_Hotel_S_D_D-DisplayedBandwidth_Hotel_S_D_D;
WastedBandwidth_Hotel_RD_D_RD = Bandwidth_Hotel_RD_D_RD-DisplayedBandwidth_Hotel_RD_D_RD;
WastedBandwidth_Hotel_RD_D_D = Bandwidth_Hotel_RD_D_D-DisplayedBandwidth_Hotel_RD_D_D;
WastedBandwidth_Invisible_RS_S_RS = Bandwidth_Invisible_RS_S_RS-DisplayedBandwidth_Invisible_RS_S_RS;
WastedBandwidth_Invisible_RS_S_S = Bandwidth_Invisible_RS_S_S-DisplayedBandwidth_Invisible_RS_S_S;
WastedBandwidth_Invisible_S_D_S = Bandwidth_Invisible_S_D_S-DisplayedBandwidth_Invisible_S_D_S;
WastedBandwidth_Invisible_S_D_D = Bandwidth_Invisible_S_D_D-DisplayedBandwidth_Invisible_S_D_D;
WastedBandwidth_Invisible_RD_D_RD = Bandwidth_Invisible_RD_D_RD-DisplayedBandwidth_Invisible_RD_D_RD;
WastedBandwidth_Invisible_RD_D_D = Bandwidth_Invisible_RD_D_D-DisplayedBandwidth_Invisible_RD_D_D;

Quality_Hotel_RS_S_RS = cell2mat(allQUAL(indexes_Hotel_RS_S_RS));
Quality_Hotel_RS_S_S = cell2mat(allQUAL(indexes_Hotel_RS_S_S));
Quality_Hotel_S_D_S = cell2mat(allQUAL(indexes_Hotel_S_D_S));
Quality_Hotel_S_D_D = cell2mat(allQUAL(indexes_Hotel_S_D_D));
Quality_Hotel_RD_D_RD = cell2mat(allQUAL(indexes_Hotel_RD_D_RD));
Quality_Hotel_RD_D_D = cell2mat(allQUAL(indexes_Hotel_RD_D_D));
Quality_Invisible_RS_S_RS = cell2mat(allQUAL(indexes_Invisible_RS_S_RS));
Quality_Invisible_RS_S_S = cell2mat(allQUAL(indexes_Invisible_RS_S_S));
Quality_Invisible_S_D_S = cell2mat(allQUAL(indexes_Invisible_S_D_S));
Quality_Invisible_S_D_D = cell2mat(allQUAL(indexes_Invisible_S_D_D));
Quality_Invisible_RD_D_RD = cell2mat(allQUAL(indexes_Invisible_RD_D_RD));
Quality_Invisible_RD_D_D = cell2mat(allQUAL(indexes_Invisible_RD_D_D));

%% Getting the t-values and p-values of the paired t-test
% HeadMotion_Hotel_RS_S_RS
% Bandwidth_Hotel_RS_S_RS
% Replacements_Hotel_RS_S_RS
% WastedBandwidth_Hotel_RS_S_RS
% DisplayedBandwidth_Hotel_RS_S_RS
% Quality_Hotel_RS_S_RS(1,:)

samples=HeadMotion_Hotel_RS_S_RS-HeadMotion_Hotel_RS_S_S;
tvalue=mean(samples)/(std(samples)/sqrt(length(samples))); pvalue=1-tcdf(tvalue,length(samples)-1); tpvalues=[tvalue,pvalue];
samples=HeadMotion_Hotel_RD_D_RD-HeadMotion_Hotel_RD_D_D;
tvalue=mean(samples)/(std(samples)/sqrt(length(samples))); pvalue=1-tcdf(tvalue,length(samples)-1); tpvalues=[tpvalues;[tvalue,pvalue]];
samples=HeadMotion_Hotel_S_D_S-HeadMotion_Hotel_S_D_D;
tvalue=mean(samples)/(std(samples)/sqrt(length(samples))); pvalue=1-tcdf(tvalue,length(samples)-1); tpvalues=[tpvalues;[tvalue,pvalue]];
samples=HeadMotion_Invisible_RS_S_RS-HeadMotion_Invisible_RS_S_S;
tvalue=mean(samples)/(std(samples)/sqrt(length(samples))); pvalue=1-tcdf(tvalue,length(samples)-1); tpvalues=[tpvalues;[tvalue,pvalue]];
samples=HeadMotion_Invisible_RD_D_RD-HeadMotion_Invisible_RD_D_D;
tvalue=mean(samples)/(std(samples)/sqrt(length(samples))); pvalue=1-tcdf(tvalue,length(samples)-1); tpvalues=[tpvalues;[tvalue,pvalue]];
samples=HeadMotion_Invisible_S_D_S-HeadMotion_Invisible_S_D_D;
tvalue=mean(samples)/(std(samples)/sqrt(length(samples))); pvalue=1-tcdf(tvalue,length(samples)-1); tpvalues=[tpvalues;[tvalue,pvalue]];

samples=Replacements_Hotel_RS_S_RS-Replacements_Hotel_RS_S_S;
tvalue=mean(samples)/(std(samples)/sqrt(length(samples))); pvalue=1-tcdf(tvalue,length(samples)-1); tpvalues=[tpvalues;[tvalue,pvalue]];
samples=Replacements_Hotel_RD_D_RD-Replacements_Hotel_RD_D_D;
tvalue=mean(samples)/(std(samples)/sqrt(length(samples))); pvalue=1-tcdf(tvalue,length(samples)-1); tpvalues=[tpvalues;[tvalue,pvalue]];
samples=Replacements_Hotel_S_D_S-Replacements_Hotel_S_D_D;
tvalue=mean(samples)/(std(samples)/sqrt(length(samples))); pvalue=1-tcdf(tvalue,length(samples)-1); tpvalues=[tpvalues;[tvalue,pvalue]];
samples=Replacements_Invisible_RS_S_RS-Replacements_Invisible_RS_S_S;
tvalue=mean(samples)/(std(samples)/sqrt(length(samples))); pvalue=1-tcdf(tvalue,length(samples)-1); tpvalues=[tpvalues;[tvalue,pvalue]];
samples=Replacements_Invisible_RD_D_RD-Replacements_Invisible_RD_D_D;
tvalue=mean(samples)/(std(samples)/sqrt(length(samples))); pvalue=1-tcdf(tvalue,length(samples)-1); tpvalues=[tpvalues;[tvalue,pvalue]];
samples=Replacements_Invisible_S_D_S-Replacements_Invisible_S_D_D;
tvalue=mean(samples)/(std(samples)/sqrt(length(samples))); pvalue=1-tcdf(tvalue,length(samples)-1); tpvalues=[tpvalues;[tvalue,pvalue]];

samples=Bandwidth_Hotel_RS_S_RS-Bandwidth_Hotel_RS_S_S;
tvalue=mean(samples)/(std(samples)/sqrt(length(samples))); pvalue=1-tcdf(tvalue,length(samples)-1); tpvalues=[tpvalues;[tvalue,pvalue]];
samples=Bandwidth_Hotel_RD_D_RD-Bandwidth_Hotel_RD_D_D;
tvalue=mean(samples)/(std(samples)/sqrt(length(samples))); pvalue=1-tcdf(tvalue,length(samples)-1); tpvalues=[tpvalues;[tvalue,pvalue]];
samples=Bandwidth_Hotel_S_D_S-Bandwidth_Hotel_S_D_D;
tvalue=mean(samples)/(std(samples)/sqrt(length(samples))); pvalue=1-tcdf(tvalue,length(samples)-1); tpvalues=[tpvalues;[tvalue,pvalue]];
samples=Bandwidth_Invisible_RS_S_RS-Bandwidth_Invisible_RS_S_S;
tvalue=mean(samples)/(std(samples)/sqrt(length(samples))); pvalue=1-tcdf(tvalue,length(samples)-1); tpvalues=[tpvalues;[tvalue,pvalue]];
samples=Bandwidth_Invisible_RD_D_RD-Bandwidth_Invisible_RD_D_D;
tvalue=mean(samples)/(std(samples)/sqrt(length(samples))); pvalue=1-tcdf(tvalue,length(samples)-1); tpvalues=[tpvalues;[tvalue,pvalue]];
samples=Bandwidth_Invisible_S_D_S-Bandwidth_Invisible_S_D_D;
tvalue=mean(samples)/(std(samples)/sqrt(length(samples))); pvalue=1-tcdf(tvalue,length(samples)-1); tpvalues=[tpvalues;[tvalue,pvalue]];

samples=WastedBandwidth_Hotel_RS_S_RS-WastedBandwidth_Hotel_RS_S_S;
tvalue=mean(samples)/(std(samples)/sqrt(length(samples))); pvalue=1-tcdf(tvalue,length(samples)-1); tpvalues=[tpvalues;[tvalue,pvalue]];
samples=WastedBandwidth_Hotel_RD_D_RD-WastedBandwidth_Hotel_RD_D_D;
tvalue=mean(samples)/(std(samples)/sqrt(length(samples))); pvalue=1-tcdf(tvalue,length(samples)-1); tpvalues=[tpvalues;[tvalue,pvalue]];
samples=WastedBandwidth_Hotel_S_D_S-WastedBandwidth_Hotel_S_D_D;
tvalue=mean(samples)/(std(samples)/sqrt(length(samples))); pvalue=1-tcdf(tvalue,length(samples)-1); tpvalues=[tpvalues;[tvalue,pvalue]];
samples=WastedBandwidth_Invisible_RS_S_RS-WastedBandwidth_Invisible_RS_S_S;
tvalue=mean(samples)/(std(samples)/sqrt(length(samples))); pvalue=1-tcdf(tvalue,length(samples)-1); tpvalues=[tpvalues;[tvalue,pvalue]];
samples=WastedBandwidth_Invisible_RD_D_RD-WastedBandwidth_Invisible_RD_D_D;
tvalue=mean(samples)/(std(samples)/sqrt(length(samples))); pvalue=1-tcdf(tvalue,length(samples)-1); tpvalues=[tpvalues;[tvalue,pvalue]];
samples=WastedBandwidth_Invisible_S_D_S-WastedBandwidth_Invisible_S_D_D;
tvalue=mean(samples)/(std(samples)/sqrt(length(samples))); pvalue=1-tcdf(tvalue,length(samples)-1); tpvalues=[tpvalues;[tvalue,pvalue]];

samples=DisplayedBandwidth_Hotel_RS_S_RS-DisplayedBandwidth_Hotel_RS_S_S;
tvalue=mean(samples)/(std(samples)/sqrt(length(samples))); pvalue=1-tcdf(tvalue,length(samples)-1); tpvalues=[tpvalues;[tvalue,pvalue]];
samples=DisplayedBandwidth_Hotel_RD_D_RD-DisplayedBandwidth_Hotel_RD_D_D;
tvalue=mean(samples)/(std(samples)/sqrt(length(samples))); pvalue=1-tcdf(tvalue,length(samples)-1); tpvalues=[tpvalues;[tvalue,pvalue]];
samples=DisplayedBandwidth_Hotel_S_D_S-DisplayedBandwidth_Hotel_S_D_D;
tvalue=mean(samples)/(std(samples)/sqrt(length(samples))); pvalue=1-tcdf(tvalue,length(samples)-1); tpvalues=[tpvalues;[tvalue,pvalue]];
samples=DisplayedBandwidth_Invisible_RS_S_RS-DisplayedBandwidth_Invisible_RS_S_S;
tvalue=mean(samples)/(std(samples)/sqrt(length(samples))); pvalue=1-tcdf(tvalue,length(samples)-1); tpvalues=[tpvalues;[tvalue,pvalue]];
samples=DisplayedBandwidth_Invisible_RD_D_RD-DisplayedBandwidth_Invisible_RD_D_D;
tvalue=mean(samples)/(std(samples)/sqrt(length(samples))); pvalue=1-tcdf(tvalue,length(samples)-1); tpvalues=[tpvalues;[tvalue,pvalue]];
samples=DisplayedBandwidth_Invisible_S_D_S-DisplayedBandwidth_Invisible_S_D_D;
tvalue=mean(samples)/(std(samples)/sqrt(length(samples))); pvalue=1-tcdf(tvalue,length(samples)-1); tpvalues=[tpvalues;[tvalue,pvalue]];

samples=Quality_Hotel_RS_S_RS(1,:)-Quality_Hotel_RS_S_S(1,:);
tvalue=mean(samples)/(std(samples)/sqrt(length(samples))); pvalue=tcdf(tvalue,length(samples)-1); tpvalues=[tpvalues;[tvalue,pvalue]];
samples=Quality_Hotel_RD_D_RD(1,:)-Quality_Hotel_RD_D_D(1,:);
tvalue=mean(samples)/(std(samples)/sqrt(length(samples))); pvalue=tcdf(tvalue,length(samples)-1); tpvalues=[tpvalues;[tvalue,pvalue]];
samples=Quality_Hotel_S_D_S(1,:)-Quality_Hotel_S_D_D(1,:);
tvalue=mean(samples)/(std(samples)/sqrt(length(samples))); pvalue=tcdf(tvalue,length(samples)-1); tpvalues=[tpvalues;[tvalue,pvalue]];
samples=Quality_Invisible_RS_S_RS(1,:)-Quality_Invisible_RS_S_S(1,:);
tvalue=mean(samples)/(std(samples)/sqrt(length(samples))); pvalue=tcdf(tvalue,length(samples)-1); tpvalues=[tpvalues;[tvalue,pvalue]];
samples=Quality_Invisible_RD_D_RD(1,:)-Quality_Invisible_RD_D_D(1,:);
tvalue=mean(samples)/(std(samples)/sqrt(length(samples))); pvalue=tcdf(tvalue,length(samples)-1); tpvalues=[tpvalues;[tvalue,pvalue]];
samples=Quality_Invisible_S_D_S(1,:)-Quality_Invisible_S_D_D(1,:);
tvalue=mean(samples)/(std(samples)/sqrt(length(samples))); pvalue=tcdf(tvalue,length(samples)-1); tpvalues=[tpvalues;[tvalue,pvalue]];

%% PLOTS
colors44 = [0 0 1; 0 0 1;0 0 1;0 0 1; 1 0 0;1 0 0; 1 0 0;1 0 0];
colors33 = [0 0 1; 0 0 1;0 0 1; 1 0 0; 1 0 0;1 0 0];
margin=0.08;

%% Diff in head motion over editings
%%{
figsub1=figure('units','normalized','outerposition',[0 0 1 1])
%subplot(3,3,1)
i=1;
h=subplot('Position',[mod(i-1,3)/3 1-ceil(i/3)/3 1/3-margin 1/3-margin]);

boxplot([(HeadMotion_Hotel_RS_S_RS-HeadMotion_Hotel_RS_S_S)'./HeadMotion_Hotel_RS_S_RS',(HeadMotion_Hotel_RD_D_RD-HeadMotion_Hotel_RD_D_D)'./HeadMotion_Hotel_RD_D_RD',(HeadMotion_Hotel_S_D_S-HeadMotion_Hotel_S_D_D)'./HeadMotion_Hotel_S_D_S',...
(HeadMotion_Invisible_RS_S_RS-HeadMotion_Invisible_RS_S_S)'./HeadMotion_Invisible_RS_S_RS',(HeadMotion_Invisible_RD_D_RD-HeadMotion_Invisible_RD_D_D)'./HeadMotion_Invisible_RD_D_RD',(HeadMotion_Invisible_S_D_S-HeadMotion_Invisible_S_D_D)'./HeadMotion_Invisible_S_D_S'],...
'Labels',{'  H: RS-S  ','  H: RD-D  ','  H: S-D  ','  I: RS-S  ','  I: RD-D  ','  I: S-D  '}, 'Colors' , colors33);
set(gca,'FontSize',12);
ax=ancestor(h,'axes');
yrule=ax.YAxis;
yrule.FontSize=16;
ylabel('relative difference','FontSize',18)
title('Head motion (diff.)','FontSize',20)
%%}

%% Diff in replacements over editings
%%{
%figure('units','normalized','outerposition',[0 0 1 1])
figure(figsub1)
% subplot(3,3,2)
i=2;
h=subplot('Position',[mod(i-1,3)/3 1-ceil(i/3)/3 1/3-margin 1/3-margin]);

boxplot([(Replacements_Hotel_RS_S_RS-Replacements_Hotel_RS_S_S)'./Replacements_Hotel_RS_S_RS',(Replacements_Hotel_RD_D_RD-Replacements_Hotel_RD_D_D)'./Replacements_Hotel_RD_D_RD',(Replacements_Hotel_S_D_S-Replacements_Hotel_S_D_D)'./Replacements_Hotel_S_D_S',...
(Replacements_Invisible_RS_S_RS-Replacements_Invisible_RS_S_S)'./Replacements_Invisible_RS_S_RS',(Replacements_Invisible_RD_D_RD-Replacements_Invisible_RD_D_D)'./Replacements_Invisible_RD_D_RD',(Replacements_Invisible_S_D_S-Replacements_Invisible_S_D_D)'./Replacements_Invisible_S_D_S'],...
'Labels',{'  H: RS-S  ','  H: RD-D  ','  H: S-D  ','  I: RS-S  ','  I: RD-D  ','  I: S-D  '}, 'Colors' , colors33);
set(gca,'FontSize',12);
ax=ancestor(h,'axes');
yrule=ax.YAxis;
yrule.FontSize=16;
ylabel('relative difference','FontSize',18)
title('Replacements (diff.)','FontSize',20)
%%}

%% Replacements vs head motion
%{
figure('units','normalized','outerposition',[0 0 1 1])
x_Hotel=[HeadMotion_Hotel_RS_S_RS';HeadMotion_Hotel_RS_S_S';HeadMotion_Hotel_S_D_S';HeadMotion_Hotel_S_D_D';HeadMotion_Hotel_RD_D_RD';HeadMotion_Hotel_RD_D_D'];
x_Invisible=[HeadMotion_Invisible_RS_S_RS';HeadMotion_Invisible_RS_S_S';HeadMotion_Invisible_S_D_S';HeadMotion_Invisible_S_D_D';HeadMotion_Invisible_RD_D_RD';HeadMotion_Invisible_RD_D_D'];
y_Hotel=[Replacements_Hotel_RS_S_RS';Replacements_Hotel_RS_S_S';Replacements_Hotel_S_D_S';Replacements_Hotel_S_D_D';Replacements_Hotel_RD_D_RD';Replacements_Hotel_RD_D_D'];
y_Invisible=[Replacements_Invisible_RS_S_RS';Replacements_Invisible_RS_S_S';Replacements_Invisible_S_D_S';Replacements_Invisible_S_D_D';Replacements_Invisible_RD_D_RD';Replacements_Invisible_RD_D_D'];
c = linspace(1,10,length([x_Hotel;x_Invisible]));
hold on
%scatter([x_Hotel;x_Invisible],[y_Hotel;y_Invisible],[],c,'filled')
h1=scatter([x_Hotel],[y_Hotel],[],'b','filled');
h2=scatter([x_Invisible],[y_Invisible],[],'r','filled');
set(gca,'FontSize',20);
xlabel('quantity of motion (°/s)','FontSize',24)
ylabel('number of replacements','FontSize',24)
%title('Nb of replacements vs qnty of motion')
b_Hotel=x_Hotel\y_Hotel;
b_Invisible=x_Invisible\y_Invisible;
plot(x_Hotel,b_Hotel*x_Hotel,'-b')
plot(x_Invisible,b_Invisible*x_Invisible,'-r')
legend([h1,h2],{'Hotel','Invisible'},'FontSize',26)
hold off
set(gcf,'units','centimeter','position',[5 5 25 15]);
%}
%% Replacements vs head motion with log analysis+
%%{
fig3=figure('units','normalized','outerposition',[0 0 1 1])
x_Hotel_S=[HeadMotion_Hotel_RS_S_RS';HeadMotion_Hotel_RS_S_S';HeadMotion_Hotel_S_D_S'];
x_Invisible_S=[HeadMotion_Invisible_RS_S_RS';HeadMotion_Invisible_RS_S_S';HeadMotion_Invisible_S_D_S'];
y_Hotel_S=[Replacements_Hotel_RS_S_RS';Replacements_Hotel_RS_S_S';Replacements_Hotel_S_D_S'];
y_Invisible_S=[Replacements_Invisible_RS_S_RS';Replacements_Invisible_RS_S_S';Replacements_Invisible_S_D_S'];
x_Hotel_D=[HeadMotion_Hotel_S_D_D';HeadMotion_Hotel_RD_D_RD';HeadMotion_Hotel_RD_D_D'];
x_Invisible_D=[HeadMotion_Invisible_S_D_D';HeadMotion_Invisible_RD_D_RD';HeadMotion_Invisible_RD_D_D'];
y_Hotel_D=[Replacements_Hotel_S_D_D';Replacements_Hotel_RD_D_RD';Replacements_Hotel_RD_D_D'];
y_Invisible_D=[Replacements_Invisible_S_D_D';Replacements_Invisible_RD_D_RD';Replacements_Invisible_RD_D_D'];
hold on
h1_S=scatter([x_Hotel_S],[y_Hotel_S],100,'b','filled');
h2_S=scatter([x_Invisible_S],[y_Invisible_S],100,'r','filled');
h1_D=scatter([x_Hotel_D],[y_Hotel_D],150,'xb');
h2_D=scatter([x_Invisible_D],[y_Invisible_D],150,'xr');
set(gca,'FontSize',20);
xlabel('quantity of motion (°/s)','FontSize',24)
ylabel('number of replacements','FontSize',24)
b_Hotel_S=x_Hotel_S\y_Hotel_S;
b_Invisible_S=x_Invisible_S\y_Invisible_S;
plot(x_Hotel_S,b_Hotel_S*x_Hotel_S,'-b')
plot(x_Invisible_S,b_Invisible_S*x_Invisible_S,'-r')

[x_Hotel_D,ind]=sort(x_Hotel_D); y_Hotel_D=y_Hotel_D(ind);
[x_Invisible_D,ind]=sort(x_Invisible_D); y_Invisible_D=y_Invisible_D(ind);
x_Hotel_D=[ones(length(x_Hotel_D),1),log(x_Hotel_D)];
b_Hotel_D=x_Hotel_D\y_Hotel_D;
x_Invisible_D=[ones(length(x_Invisible_D),1),log(x_Invisible_D)];
b_Invisible_D=x_Invisible_D\y_Invisible_D;
plot(exp(x_Hotel_D(:,2)),b_Hotel_D'*x_Hotel_D','-b')
plot(exp(x_Invisible_D(:,2)),b_Invisible_D'*x_Invisible_D','-r')

legend([h1_S,h2_S,h1_D,h2_D],{'Hotel, S and RS','Invisible, S and RS','Hotel, D and RD','Invisible, D and RD'},'FontSize',20)
hold off
ylim([0 1400])
set(gcf,'units','centimeter','position',[5 5 30 20]);
%}

%%%% Total bw
%%Total bw vs replacements
%%{
fig2=figure('units','normalized','outerposition',[0 0 1 1])
i=1;
h=subplot('Position',[mod(i-1,3)/3+margin 2*margin 1/3-1.22*margin 1-3*margin]);
x_Hotel=[Replacements_Hotel_RS_S_RS';Replacements_Hotel_RS_S_S';Replacements_Hotel_S_D_S';Replacements_Hotel_S_D_D';Replacements_Hotel_RD_D_RD';Replacements_Hotel_RD_D_D'];
x_Invisible=[Replacements_Invisible_RS_S_RS';Replacements_Invisible_RS_S_S';Replacements_Invisible_S_D_S';Replacements_Invisible_S_D_D';Replacements_Invisible_RD_D_RD';Replacements_Invisible_RD_D_D'];
y_Hotel=[Bandwidth_Hotel_RS_S_RS';Bandwidth_Hotel_RS_S_S';Bandwidth_Hotel_S_D_S';Bandwidth_Hotel_S_D_D';Bandwidth_Hotel_RD_D_RD';Bandwidth_Hotel_RD_D_D'];
y_Invisible=[Bandwidth_Invisible_RS_S_RS';Bandwidth_Invisible_RS_S_S';Bandwidth_Invisible_S_D_S';Bandwidth_Invisible_S_D_D';Bandwidth_Invisible_RD_D_RD';Bandwidth_Invisible_RD_D_D'];
hold on
h1=scatter([x_Hotel],[y_Hotel],[],'b','filled');
h2=scatter([x_Invisible],[y_Invisible],[],'r','filled');
set(gca,'FontSize',20);
xlabel('number of replacements','FontSize',24)
ylabel('total bandwidth (MB)','FontSize',24)
x_Hotel=[ones(length(x_Hotel),1),x_Hotel];
b_Hotel=x_Hotel\y_Hotel;
x_Invisible=[ones(length(x_Invisible),1),x_Invisible];
b_Invisible=x_Invisible\y_Invisible;
plot(x_Hotel(:,2),b_Hotel'*x_Hotel','-b')
plot(x_Invisible(:,2),b_Invisible'*x_Invisible','-r')
set(gca,'FontSize',14);
ax=ancestor(h,'axes');
yrule=ax.YAxis;
yrule.FontSize=18;
hold off
%}

%% Diff in total bw over editings
%%{
figure(figsub1)
i=4;
h=subplot('Position',[mod(i-1,3)/3 1-ceil(i/3)/3 1/3-margin 1/3-margin]);

boxplot([(Bandwidth_Hotel_RS_S_RS-Bandwidth_Hotel_RS_S_S)'./Bandwidth_Hotel_RS_S_RS',(Bandwidth_Hotel_RD_D_RD-Bandwidth_Hotel_RD_D_D)'./Bandwidth_Hotel_RD_D_RD',(Bandwidth_Hotel_S_D_S-Bandwidth_Hotel_S_D_D)'./Bandwidth_Hotel_S_D_S',...
(Bandwidth_Invisible_RS_S_RS-Bandwidth_Invisible_RS_S_S)'./Bandwidth_Invisible_RS_S_RS',(Bandwidth_Invisible_RD_D_RD-Bandwidth_Invisible_RD_D_D)'./Bandwidth_Invisible_RD_D_RD',(Bandwidth_Invisible_S_D_S-Bandwidth_Invisible_S_D_D)'./Bandwidth_Invisible_S_D_S'],...
'Labels',{'  H: RS-S  ','  H: RD-D  ','  H: S-D  ','  I: RS-S  ','  I: RD-D  ','  I: S-D  '}, 'Colors' , colors33);
set(gca,'FontSize',12);
ax=ancestor(h,'axes');
yrule=ax.YAxis;
yrule.FontSize=16;
ylabel('relative difference','FontSize',18)
title('Total bandwidth (diff.)','FontSize',20)
%}

%% Diff in wasted bw over editings
%%{
figure(figsub1)
i=5;
h=subplot('Position',[mod(i-1,3)/3 1-ceil(i/3)/3 1/3-margin 1/3-margin]);

boxplot([(WastedBandwidth_Hotel_RS_S_RS-WastedBandwidth_Hotel_RS_S_S)'./WastedBandwidth_Hotel_RS_S_RS',(WastedBandwidth_Hotel_RD_D_RD-WastedBandwidth_Hotel_RD_D_D)'./WastedBandwidth_Hotel_RD_D_RD',(WastedBandwidth_Hotel_S_D_S-WastedBandwidth_Hotel_S_D_D)'./WastedBandwidth_Hotel_S_D_S',...
(WastedBandwidth_Invisible_RS_S_RS-WastedBandwidth_Invisible_RS_S_S)'./WastedBandwidth_Invisible_RS_S_RS',(WastedBandwidth_Invisible_RD_D_RD-WastedBandwidth_Invisible_RD_D_D)'./WastedBandwidth_Invisible_RD_D_RD',(WastedBandwidth_Invisible_S_D_S-WastedBandwidth_Invisible_S_D_D)'./WastedBandwidth_Invisible_S_D_S'],...
'Labels',{'  H: RS-S  ','  H: RD-D  ','  H: S-D  ','  I: RS-S  ','  I: RD-D  ','  I: S-D  '}, 'Colors' , colors33);
set(gca,'FontSize',12);
ax=ancestor(h,'axes');
yrule=ax.YAxis;
yrule.FontSize=16;
ylabel('relative difference','FontSize',18)
title('Wasted bandwidth (diff.)','FontSize',20)
%}

%%%% Wasted
%% Wasted bw vs replacements
%%{
figure(fig2)
i=2;
h=subplot('Position',[mod(i-1,3)/3+margin 2*margin 1/3-1.22*margin 1-3*margin]);
x_Hotel=[Replacements_Hotel_RS_S_RS';Replacements_Hotel_RS_S_S';Replacements_Hotel_S_D_S';Replacements_Hotel_S_D_D';Replacements_Hotel_RD_D_RD';Replacements_Hotel_RD_D_D'];
x_Invisible=[Replacements_Invisible_RS_S_RS';Replacements_Invisible_RS_S_S';Replacements_Invisible_S_D_S';Replacements_Invisible_S_D_D';Replacements_Invisible_RD_D_RD';Replacements_Invisible_RD_D_D'];
y_Hotel=[WastedBandwidth_Hotel_RS_S_RS';WastedBandwidth_Hotel_RS_S_S';WastedBandwidth_Hotel_S_D_S';WastedBandwidth_Hotel_S_D_D';WastedBandwidth_Hotel_RD_D_RD';WastedBandwidth_Hotel_RD_D_D'];
y_Invisible=[WastedBandwidth_Invisible_RS_S_RS';WastedBandwidth_Invisible_RS_S_S';WastedBandwidth_Invisible_S_D_S';WastedBandwidth_Invisible_S_D_D';WastedBandwidth_Invisible_RD_D_RD';WastedBandwidth_Invisible_RD_D_D'];
hold on
h1=scatter([x_Hotel],[y_Hotel],[],'b','filled')
h2=scatter([x_Invisible],[y_Invisible],[],'r','filled')
set(gca,'FontSize',20);
xlabel('number of replacements','FontSize',24)
ylabel('wasted bandwidth (MB)','FontSize',24)
x_Hotel=[ones(length(x_Hotel),1),x_Hotel];
b_Hotel=x_Hotel\y_Hotel;
x_Invisible=[ones(length(x_Invisible),1),x_Invisible];
b_Invisible=x_Invisible\y_Invisible;
plot(x_Hotel(:,2),b_Hotel'*x_Hotel','-b')
plot(x_Invisible(:,2),b_Invisible'*x_Invisible','-r')
set(gca,'FontSize',14);
ax=ancestor(h,'axes');
yrule=ax.YAxis;
yrule.FontSize=18;
hold off
%}

%%%% Displayed
%% Displayed bw vs rpl
figure(fig2)
i=3;
h=subplot('Position',[mod(i-1,3)/3+margin 2*margin 1/3-1.22*margin 1-3*margin]);
x_Hotel=[Replacements_Hotel_RS_S_RS';Replacements_Hotel_RS_S_S';Replacements_Hotel_S_D_S';Replacements_Hotel_S_D_D';Replacements_Hotel_RD_D_RD';Replacements_Hotel_RD_D_D'];
x_Invisible=[Replacements_Invisible_RS_S_RS';Replacements_Invisible_RS_S_S';Replacements_Invisible_S_D_S';Replacements_Invisible_S_D_D';Replacements_Invisible_RD_D_RD';Replacements_Invisible_RD_D_D'];
y_Hotel=[DisplayedBandwidth_Hotel_RS_S_RS';DisplayedBandwidth_Hotel_RS_S_S';DisplayedBandwidth_Hotel_S_D_S';DisplayedBandwidth_Hotel_S_D_D';DisplayedBandwidth_Hotel_RD_D_RD';DisplayedBandwidth_Hotel_RD_D_D'];
y_Invisible=[DisplayedBandwidth_Invisible_RS_S_RS';DisplayedBandwidth_Invisible_RS_S_S';DisplayedBandwidth_Invisible_S_D_S';DisplayedBandwidth_Invisible_S_D_D';DisplayedBandwidth_Invisible_RD_D_RD';DisplayedBandwidth_Invisible_RD_D_D'];
hold on
h1=scatter([x_Hotel],[y_Hotel],[],'b','filled')
h2=scatter([x_Invisible],[y_Invisible],[],'r','filled')
set(gca,'FontSize',20);
xlabel('number of replacements','FontSize',24)
ylabel('displayed bandwidth (MB)','FontSize',24)
x_Hotel=[ones(length(x_Hotel),1),x_Hotel];
b_Hotel=x_Hotel\y_Hotel;
x_Invisible=[ones(length(x_Invisible),1),x_Invisible];
b_Invisible=x_Invisible\y_Invisible;
plot(x_Hotel(:,2),b_Hotel'*x_Hotel','-b')
plot(x_Invisible(:,2),b_Invisible'*x_Invisible','-r')
legend([h1,h2],{'Hotel','Invisible'},'FontSize',20,'Location','southeast')
set(gca,'FontSize',14);
ax=ancestor(h,'axes');
yrule=ax.YAxis;
yrule.FontSize=18;
hold off
set(gcf,'units','centimeter','position',[5 5 30 10]);

%% Diff in displayed bw over editings
%%{
figure(figsub1)
i=6;
h=subplot('Position',[mod(i-1,3)/3 1-ceil(i/3)/3 1/3-margin 1/3-margin]);

boxplot([(DisplayedBandwidth_Hotel_RS_S_RS-DisplayedBandwidth_Hotel_RS_S_S)'./DisplayedBandwidth_Hotel_RS_S_RS',(DisplayedBandwidth_Hotel_RD_D_RD-DisplayedBandwidth_Hotel_RD_D_D)'./DisplayedBandwidth_Hotel_RD_D_RD',(DisplayedBandwidth_Hotel_S_D_S-DisplayedBandwidth_Hotel_S_D_D)'./DisplayedBandwidth_Hotel_S_D_S',...
(DisplayedBandwidth_Invisible_RS_S_RS-DisplayedBandwidth_Invisible_RS_S_S)'./DisplayedBandwidth_Invisible_RS_S_RS',(DisplayedBandwidth_Invisible_RD_D_RD-DisplayedBandwidth_Invisible_RD_D_D)'./DisplayedBandwidth_Invisible_RD_D_RD',(DisplayedBandwidth_Invisible_S_D_S-DisplayedBandwidth_Invisible_S_D_D)'./DisplayedBandwidth_Invisible_S_D_S'],...
'Labels',{'  H: RS-S  ','  H: RD-D  ','  H: S-D  ','  I: RS-S  ','  I: RD-D  ','  I: S-D  '}, 'Colors' , colors33);
set(gca,'FontSize',12);
ax=ancestor(h,'axes');
yrule=ax.YAxis;
yrule.FontSize=16;
ylabel('relative difference','FontSize',18)
title('Displayed bandwidth (diff.)','FontSize',20)
%}

%% Total bw over the editings
%%{
figure(figsub1)
i=7;
h=subplot('Position',[mod(i-1,3)/3 1-ceil(i/3)/3 1/3-margin 1/3-margin]);

boxplot([Bandwidth_Hotel_RS_S_RS';Bandwidth_Hotel_RD_D_RD';Bandwidth_Hotel_RS_S_S';Bandwidth_Hotel_S_D_S';Bandwidth_Hotel_RD_D_D';Bandwidth_Hotel_S_D_D';...
Bandwidth_Invisible_RS_S_RS';Bandwidth_Invisible_RD_D_RD';Bandwidth_Invisible_RS_S_S';Bandwidth_Invisible_S_D_S';Bandwidth_Invisible_RD_D_D';Bandwidth_Invisible_S_D_D'],...
[repmat('H: RS',length(Bandwidth_Hotel_RS_S_RS),1);repmat('H: RD',length(Bandwidth_Hotel_RD_D_RD),1);repmat(' H: S',length([Bandwidth_Hotel_RS_S_S';Bandwidth_Hotel_S_D_S']),1);repmat(' H: D',length([Bandwidth_Hotel_RD_D_D';Bandwidth_Hotel_S_D_D']),1);...
repmat('I: RS',length(Bandwidth_Invisible_RS_S_RS),1);repmat('I: RD',length(Bandwidth_Invisible_RD_D_RD),1);repmat('I: S ',length([Bandwidth_Invisible_RS_S_S';Bandwidth_Invisible_S_D_S']),1);repmat(' I: D',length([Bandwidth_Invisible_RD_D_D';Bandwidth_Invisible_S_D_D']),1)],...
'Colors' , colors44);
set(gca,'FontSize',12);
ax=ancestor(h,'axes');
yrule=ax.YAxis;
yrule.FontSize=16;
ylabel('bandwidth (MB)','FontSize',18)
title('Total bandwidth','FontSize',20)
%}
%% Wasted bw over the editings
%%{
figure(figsub1)
i=8;
h=subplot('Position',[mod(i-1,3)/3 1-ceil(i/3)/3 1/3-margin 1/3-margin]);

boxplot([WastedBandwidth_Hotel_RS_S_RS';WastedBandwidth_Hotel_RD_D_RD';WastedBandwidth_Hotel_RS_S_S';WastedBandwidth_Hotel_S_D_S';WastedBandwidth_Hotel_RD_D_D';WastedBandwidth_Hotel_S_D_D';...
WastedBandwidth_Invisible_RS_S_RS';WastedBandwidth_Invisible_RD_D_RD';WastedBandwidth_Invisible_RS_S_S';WastedBandwidth_Invisible_S_D_S';WastedBandwidth_Invisible_RD_D_D';WastedBandwidth_Invisible_S_D_D'],...
[repmat('H: RS',length(WastedBandwidth_Hotel_RS_S_RS),1);repmat('H: RD',length(WastedBandwidth_Hotel_RD_D_RD),1);repmat(' H: S',length([WastedBandwidth_Hotel_RS_S_S';WastedBandwidth_Hotel_S_D_S']),1);repmat(' H: D',length([WastedBandwidth_Hotel_RD_D_D';WastedBandwidth_Hotel_S_D_D']),1);...
repmat('I: RS',length(WastedBandwidth_Invisible_RS_S_RS),1);repmat('I: RD',length(WastedBandwidth_Invisible_RD_D_RD),1);repmat(' I: S',length([WastedBandwidth_Invisible_RS_S_S';WastedBandwidth_Invisible_S_D_S']),1);repmat(' I: D',length([WastedBandwidth_Invisible_RD_D_D';WastedBandwidth_Invisible_S_D_D']),1)],...
'Colors' , colors44);
set(gca,'FontSize',12);
ax=ancestor(h,'axes');
yrule=ax.YAxis;
yrule.FontSize=16;
ylabel('bandwidth (MB)','FontSize',18)
title('Wasted bandwidth','FontSize',20)
%}
%% Displayed bw over the editings
%%{
figure(figsub1)
i=9;
h=subplot('Position',[mod(i-1,3)/3 1-ceil(i/3)/3 1/3-margin 1/3-margin]);

boxplot([DisplayedBandwidth_Hotel_RS_S_RS';DisplayedBandwidth_Hotel_RD_D_RD';DisplayedBandwidth_Hotel_RS_S_S';DisplayedBandwidth_Hotel_S_D_S';DisplayedBandwidth_Hotel_RD_D_D';DisplayedBandwidth_Hotel_S_D_D';...
DisplayedBandwidth_Invisible_RS_S_RS';DisplayedBandwidth_Invisible_RD_D_RD';DisplayedBandwidth_Invisible_RS_S_S';DisplayedBandwidth_Invisible_S_D_S';DisplayedBandwidth_Invisible_RD_D_D';DisplayedBandwidth_Invisible_S_D_D'],...
[repmat('H: RS',length(DisplayedBandwidth_Hotel_RS_S_RS),1);repmat('H: RD',length(DisplayedBandwidth_Hotel_RD_D_RD),1);repmat(' H: S',length([DisplayedBandwidth_Hotel_RS_S_S';DisplayedBandwidth_Hotel_S_D_S']),1);repmat(' H: D',length([DisplayedBandwidth_Hotel_RD_D_D';DisplayedBandwidth_Hotel_S_D_D']),1);...
repmat('I: RS',length(DisplayedBandwidth_Invisible_RS_S_RS),1);repmat('I: RD',length(DisplayedBandwidth_Invisible_RD_D_RD),1);repmat(' I: S',length([DisplayedBandwidth_Invisible_RS_S_S';DisplayedBandwidth_Invisible_S_D_S']),1);repmat(' I: D',length([DisplayedBandwidth_Invisible_RD_D_D';DisplayedBandwidth_Invisible_S_D_D']),1)],...
'Colors' , colors44);
set(gca,'FontSize',12);
ax=ancestor(h,'axes');
yrule=ax.YAxis;
yrule.FontSize=16;
ylabel('bandwidth (MB)','FontSize',18)
title('Displayed bandwidth','FontSize',20)
%}

%% FoVQuality over the editings
%%{
figure(figsub1)
i=3;
h=subplot('Position',[mod(i-1,3)/3 1-ceil(i/3)/3 1/3-margin 1/3-margin]);

boxplot([Quality_Hotel_RS_S_RS(1,:)';Quality_Hotel_RD_D_RD(1,:)';Quality_Hotel_RS_S_S(1,:)';Quality_Hotel_S_D_S(1,:)';Quality_Hotel_RD_D_D(1,:)';Quality_Hotel_S_D_D(1,:)';...
Quality_Invisible_RS_S_RS(1,:)';Quality_Invisible_RD_D_RD(1,:)';Quality_Invisible_RS_S_S(1,:)';Quality_Invisible_S_D_S(1,:)';Quality_Invisible_RD_D_D(1,:)';Quality_Invisible_S_D_D(1,:)'],...
[repmat('H: RS',length(WastedBandwidth_Hotel_RS_S_RS),1);repmat('H: RD',length(WastedBandwidth_Hotel_RD_D_RD),1);repmat(' H: S',length([WastedBandwidth_Hotel_RS_S_S';WastedBandwidth_Hotel_S_D_S']),1);repmat(' H: D',length([WastedBandwidth_Hotel_RD_D_D';WastedBandwidth_Hotel_S_D_D']),1);...
repmat('I: RS',length(WastedBandwidth_Invisible_RS_S_RS),1);repmat('I: RD',length(WastedBandwidth_Invisible_RD_D_RD),1);repmat(' I: S',length([WastedBandwidth_Invisible_RS_S_S';WastedBandwidth_Invisible_S_D_S']),1);repmat(' I: D',length([WastedBandwidth_Invisible_RD_D_D';WastedBandwidth_Invisible_S_D_D']),1)],...
'Colors' , colors44);
set(gca,'FontSize',12);
ax=ancestor(h,'axes');
yrule=ax.YAxis;
yrule.FontSize=16;
ylabel('relative quality','FontSize',18)
title('FoV quality','FontSize',20)
%}

%% SphereQuality over the editings
%{
%figure('units','normalized','outerposition',[0 0 1 1])
figure(figsub1)
subplot(3,3,8)
boxplot([Quality_Hotel_S_D_S(2,:)';Quality_Hotel_S_D_D(2,:)';...
Quality_Invisible_S_D_S(2,:)';Quality_Invisible_S_D_D(2,:)'],...
[repmat('Hotel S    ',length(HeadMotion_Hotel_S_D_S),1);repmat('Hotel D    ',length(HeadMotion_Hotel_S_D_D),1);repmat('Invisible S',length(HeadMotion_Invisible_S_D_S),1);;repmat('Invisible D',length(HeadMotion_Invisible_S_D_D),1)],...
'Colors' , colors);
%hLegend = legend(findall(gca, 'Tag', 'Box'), {'Hotel Random Static (RS)','Hotel Static (S)'});
%xlabel('Average Head Motion (°/s)')
ylabel('Sphere quality')
title('Sphere quality')
%ylim([0.5,1])
%}

%% Weight_dispHQ over the editings
%{
%figure('units','normalized','outerposition',[0 0 1 1])
figure(figsub1)
subplot(3,3,9)
boxplot([Quality_Hotel_S_D_S(3,:)';Quality_Hotel_S_D_D(3,:)';...
Quality_Invisible_S_D_S(3,:)';Quality_Invisible_S_D_D(3,:)'],...
[repmat('Hotel S    ',length(HeadMotion_Hotel_S_D_S),1);repmat('Hotel D    ',length(HeadMotion_Hotel_S_D_D),1);repmat('Invisible S',length(HeadMotion_Invisible_S_D_S),1);;repmat('Invisible D',length(HeadMotion_Invisible_S_D_D),1)],...
'Colors' , colors);
%hLegend = legend(findall(gca, 'Tag', 'Box'), {'Hotel Random Static (RS)','Hotel Static (S)'});
%xlabel('Average Head Motion (°/s)')
ylabel('Weight displayed HQ')
title('Weight displayed HQ')
%}

%set(gca,'FontSize',20);