%% Script to post-process the users' data from Oct. 2017 experiments (i.e., set 2 of experiments) and plot corresponding figures
%% Pairwise tests have been run between only 2 of the proposed editings:
%% Static (S) vs. Dynamic (D)

clear
clc
close all
%%{
directory_name = '../../data_from_exp/LogFiles_OctExp/';


Hotel_S_part1_userind=[2,6,10,15,17,21];
Hotel_S_part2_userind=[4,8,12,14,19];
Hotel_D_part1_userind=[4,8,12,14,19];
Hotel_D_part2_userind=[2,6,10,15,17,21];
Invisible_S_part1_userind=[1,5,9,13,18];
Invisible_S_part2_userind=[3,7,11,16,20];
Invisible_D_part1_userind=[3,7,11,16,20];
Invisible_D_part2_userind=[1,5,9,13,18];
exp_reg={Hotel_S_part1_userind,Hotel_S_part2_userind,Hotel_D_part1_userind,Hotel_D_part2_userind,...
    Invisible_S_part1_userind,Invisible_S_part2_userind,Invisible_D_part1_userind,Invisible_D_part2_userind};
%%{
indexes_HOTEL_S_D_S=[]; indexes_INVISIBLE_S_D_S=[];
indexes_HOTEL_S_D_D=[]; indexes_INVISIBLE_S_D_D=[];
allBW=cell(1,size(exp_reg,2)); allHM=cell(1,size(exp_reg,2)); allRPL=cell(1,size(exp_reg,2)); allDBW=cell(1,size(exp_reg,2)); allQUAL=cell(1,size(exp_reg,2));
for class_exp_ind = 1:size(exp_reg,2)
    if mod(class_exp_ind,2)==0,
        part=2;
    else,
        part=1;
    end;
    if class_exp_ind <=4,
        content='Hotel';
    else,
        content='Invisible';
    end;
    if mod(class_exp_ind,4)==1||mod(class_exp_ind,4)==2,
        editing='S';
    else,
        editing='D';
    end;
    if strcmp(content,'Hotel')&&strcmp(editing,'S'),
        indexes_HOTEL_S_D_S=[indexes_HOTEL_S_D_S,class_exp_ind];
    elseif strcmp(content,'Hotel')&&strcmp(editing,'D'),
        indexes_HOTEL_S_D_D=[indexes_HOTEL_S_D_D,class_exp_ind];
    elseif strcmp(content,'Invisible')&&strcmp(editing,'S'),
        indexes_INVISIBLE_S_D_S=[indexes_INVISIBLE_S_D_S,class_exp_ind];
    elseif strcmp(content,'Invisible')&&strcmp(editing,'D'),
        indexes_INVISIBLE_S_D_D=[indexes_INVISIBLE_S_D_D,class_exp_ind];
    else,
        error('wrong index here');
    end;
    users_ind=cell2mat(exp_reg(class_exp_ind));
    bw_users_exp=[]; rpl_users_exp=[]; hm_users_exp=[]; dispbw_users_exp=[]; quality_users_exp=[];
    for user_ind=1:length(users_ind),
        % get the headMotion file
        path=[directory_name,'user',num2str(users_ind(user_ind))];
        files = dir(path);
        fileIndex = find(~[files.isdir]);
        for i = 1:length(fileIndex),
            fileName = files(fileIndex(i)).name;
            if contains(fileName,editing)&&contains(fileName,'headMotion')
                headMotionFile=fileName;
            elseif contains(fileName,editing)&&contains(fileName,'repl')
                replacementsFile=fileName;
            elseif contains(fileName,editing)&&contains(fileName,'bandwidth')
                bandwidthFile=fileName;
            elseif contains(fileName,editing)&&contains(fileName,'Qual')
                tileQualityFile=fileName;
            elseif contains(fileName,editing)&&contains(fileName,'picked')
                pickedTilesFile=fileName;
            end
        end
        %%% To filter out initial and final stages (user puts on or removes HMD)
        time_start=5; % in sec
        if strcmp(content,'Hotel'),
            time_end=80;
        elseif strcmp(content,'Invisible'),
            time_end=190;
        end
        % compute the quantities
        bw_user = csvread([path,'/',bandwidthFile]);
        ind_start=find(bw_user(:,2)-bw_user(1,2)>=time_start*10^3); ind_start=ind_start(1);
        ind_end=find(bw_user(:,2)-bw_user(1,2)>=time_end*10^3); if ~isempty(ind_end), ind_end=ind_end(1); else, ind_end=size(bw_user,1); end;
        bw_users_exp= [bw_users_exp,(bw_user(ind_end,3))/10^6];
        rpl_user = csvread([path,'/',replacementsFile]);
        ind_start=find(rpl_user(:,1)-bw_user(1,2)>=time_start*10^3); if ~isempty(ind_start), ind_start=ind_start(1); else, ind_start=1; end;
        rpl_user=rpl_user(ind_start:end,:);
        ind_end=find(rpl_user(:,1)-bw_user(1,2)>=time_end*10^3); if ~isempty(ind_end), ind_end=ind_end(1); else, ind_end=size(rpl_user,1); end;
        rpl_user=rpl_user(1:ind_end,:);
        rpl_users_exp= [rpl_users_exp,length(rpl_user(:,1))];
        
        tilequal= csvread([path,'/',tileQualityFile]);
        ind_start=find(tilequal(:,1)-bw_user(1,2)>=time_start*10^3); ind_start=ind_start(1);
        ind_end=find(tilequal(:,1)-bw_user(1,2)>=time_end*10^3); if ~isempty(ind_end), ind_end=ind_end(1); else, ind_end=size(tilequal,1); end;
        ind_seg_start=tilequal(ind_start,3);
        ind_seg_end=tilequal(ind_end,3);
        tilequal=tilequal(tilequal(:,3)>=ind_seg_start,:);
        tilequal=tilequal(tilequal(:,3)<=ind_seg_end,:);
        dispbw_user=compute_DisplayedBw_OctExp(tilequal,content,editing,part);
        dispbw_users_exp = [dispbw_users_exp, dispbw_user];
    
        pickedtiles= csvread([path,'/',pickedTilesFile]);
        ind_start=find(pickedtiles(:,1)-bw_user(1,2)>=time_start*10^3); ind_start=ind_start(1);
        ind_end=find(pickedtiles(:,1)-bw_user(1,2)>=time_end*10^3); if ~isempty(ind_end), ind_end=ind_end(1); else, ind_end=size(pickedtiles,1); end;
        pickedtiles=pickedtiles(ind_start:ind_end,:);
        quality_user=compute_Quality_OctExp(tilequal,pickedtiles,[path,'/',headMotionFile],content,part,users_ind(user_ind),editing);
        quality_users_exp=[quality_users_exp,quality_user];
        
        %%% Head motion: computes time series, detect then correct abnormalities (i.e., jumps from -180° to +180° corresponding to smooth motion)
        % This command may require setting the absolute path
        if users_ind(user_ind)==21 && strcmp(editing,'D'),
            system(['python3 ../DataVisualization/headprocess_OctExp.py -w 53 -d 200 -i "',path,'/',headMotionFile,'" -u ',num2str(users_ind(user_ind)),' -e "',editing,'"']);
        else,
            system(['python3 ../DataVisualization/headprocess_OctExp.py -i "',path,'/',headMotionFile,'" -u ',num2str(users_ind(user_ind)),' -e "',editing,'"']);
        end;
        load([path,'/user',num2str(users_ind(user_ind)),'_',editing,'_hm.mat']);
        ind_start=find(headMotion_time>=time_start); ind_start=ind_start(1);
        ind_end=find(headMotion_time>=time_end); if ~isempty(ind_end), ind_end=ind_end(1); else, ind_end=length(headMotion_time); end;
        
        headMotion_meanVelocity=headMotion_meanVelocity(ind_start:ind_end);
        headMotion_velocityX=headMotion_velocityX(ind_start:ind_end);
        headMotion_velocityY=headMotion_velocityY(ind_start:ind_end);
        headMotion_positionX=headMotion_positionX(ind_start:ind_end);
        headMotion_positionY=headMotion_positionY(ind_start:ind_end);
        headMotion_time=headMotion_time(ind_start:ind_end);
        %%% Check sanity of the head motion data
        if (users_ind(user_ind)~=21 || ~strcmp(editing,'D'))&&(sum(abs(headMotion_velocityX)>510)+sum(abs(headMotion_velocityY)>510)>0),
            system(['python3 ../DataVisualization/headprocess_OctExp.py -w 20 -i "',path,'/',headMotionFile,'" -u ',num2str(users_ind(user_ind)),' -e "',editing,'"']);
            load([path,'/user',num2str(users_ind(user_ind)),'_',editing,'_hm.mat']);
            ind_start=find(headMotion_time>=time_start); ind_start=ind_start(1);
            ind_end=find(headMotion_time>=time_end); if ~isempty(ind_end), ind_end=ind_end(1); else, ind_end=length(headMotion_time); end;
            headMotion_meanVelocity=headMotion_meanVelocity(ind_start:ind_end);
            
            headMotion_velocityX=headMotion_velocityX(ind_start:ind_end);
            headMotion_velocityY=headMotion_velocityY(ind_start:ind_end);
            headMotion_positionX=headMotion_positionX(ind_start:ind_end);
            headMotion_positionY=headMotion_positionY(ind_start:ind_end);
            headMotion_time=headMotion_time(ind_start:ind_end);
        end;
        hm_user = headMotion_meanVelocity;
        hm_users_exp= [hm_users_exp,hm_user(end)];
    end
    allBW{class_exp_ind}=bw_users_exp; allHM{class_exp_ind}=hm_users_exp; allRPL{class_exp_ind}=rpl_users_exp; 
    allDBW{class_exp_ind}=dispbw_users_exp; allQUAL{class_exp_ind}=quality_users_exp; 
end
%}

%% Getting the parameters for the FoV size
classind_Hotel_S_part1=1; classind_Hotel_S_part2=2; classind_Hotel_D_part1=3; classind_Hotel_D_part2=4;
classind_Invisible_S_part1=5; classind_Invisible_S_part2=6; classind_Invisible_D_part1=7; classind_Invisible_D_part2=8;

meanqual_Hotel_S_part1= mean(cell2mat(allQUAL(classind_Hotel_S_part1)),2); FoVsize_Hotel_S_part1=meanqual_Hotel_S_part1(2,1);
meanqual_Hotel_S_part2= mean(cell2mat(allQUAL(classind_Hotel_S_part2)),2); FoVsize_Hotel_S_part2=meanqual_Hotel_S_part2(2,1);
meanqual_Invisible_S_part1= mean(cell2mat(allQUAL(classind_Invisible_S_part1)),2); FoVsize_Invisible_S_part1=meanqual_Invisible_S_part1(2,1);
meanqual_Invisible_S_part2= mean(cell2mat(allQUAL(classind_Invisible_S_part2)),2); FoVsize_Invisible_S_part2=meanqual_Invisible_S_part2(2,1);

%%% FoV size computation for dynamic editing
% The tile picker has drifted with snap-changes, and has increased the
% number of tiles in the FoV (size of FoVs above). This will be fixed in the next TOUCAN-VR
% version. The below lines are meant to correct the FoV size of dynamic.
% nb of segments given by the time boundaries, given 1 seg is 1 sec
meanqual_Hotel_D_part1= mean(cell2mat(allQUAL(classind_Hotel_D_part1)),2); 
FoVsize_Hotel_D_part1=meanqual_Hotel_D_part1(2,1); 
meanweightHQ_Hotel_D_part1=meanqual_Hotel_D_part1(3,1);
meanweightLQ_Hotel_D_part1=meanqual_Hotel_D_part1(4,1);
bwtocut=1/10^6*(time_end-time_start)*(FoVsize_Hotel_D_part1-FoVsize_Hotel_S_part1)*(meanweightHQ_Hotel_D_part1-meanweightLQ_Hotel_D_part1);
allBW{classind_Hotel_D_part1}=allBW{classind_Hotel_D_part1}-bwtocut;
allDBW{classind_Hotel_D_part1}=allDBW{classind_Hotel_D_part1}-bwtocut;
temp=allQUAL{classind_Hotel_D_part1}; temp(1,:)=temp(1,:)/FoVsize_Hotel_D_part1; allQUAL{classind_Hotel_D_part1}=temp;
temp=allQUAL{classind_Hotel_S_part1}; temp(1,:)=temp(1,:)/FoVsize_Hotel_S_part1; allQUAL{classind_Hotel_S_part1}=temp;

meanqual_Hotel_D_part2= mean(cell2mat(allQUAL(classind_Hotel_D_part2)),2); 
FoVsize_Hotel_D_part2=meanqual_Hotel_D_part2(2,1); 
meanweightHQ_Hotel_D_part2=meanqual_Hotel_D_part2(3,1);
meanweightLQ_Hotel_D_part2=meanqual_Hotel_D_part2(4,1);
bwtocut=1/10^6*(time_end-time_start)*(FoVsize_Hotel_D_part2-FoVsize_Hotel_S_part2)*(meanweightHQ_Hotel_D_part2-meanweightLQ_Hotel_D_part2);
allBW{classind_Hotel_D_part2}=allBW{classind_Hotel_D_part2}-bwtocut;
allDBW{classind_Hotel_D_part2}=allDBW{classind_Hotel_D_part2}-bwtocut;
temp=allQUAL{classind_Hotel_D_part2}; temp(1,:)=temp(1,:)/FoVsize_Hotel_D_part2; allQUAL{classind_Hotel_D_part2}=temp;
temp=allQUAL{classind_Hotel_S_part2}; temp(1,:)=temp(1,:)/FoVsize_Hotel_S_part2; allQUAL{classind_Hotel_S_part2}=temp;

meanqual_Invisible_D_part1= mean(cell2mat(allQUAL(classind_Invisible_D_part1)),2); 
FoVsize_Invisible_D_part1=meanqual_Invisible_D_part1(2,1); 
meanweightHQ_Invisible_D_part1=meanqual_Invisible_D_part1(3,1);
meanweightLQ_Invisible_D_part1=meanqual_Invisible_D_part1(4,1);
bwtocut=1/10^6*(time_end-time_start)*(FoVsize_Invisible_D_part1-FoVsize_Invisible_S_part1)*(meanweightHQ_Invisible_D_part1-meanweightLQ_Invisible_D_part1);
allBW{classind_Invisible_D_part1}=allBW{classind_Invisible_D_part1}-bwtocut;
allDBW{classind_Invisible_D_part1}=allDBW{classind_Invisible_D_part1}-bwtocut;
temp=allQUAL{classind_Invisible_D_part1}; temp(1,:)=temp(1,:)/FoVsize_Invisible_D_part1; allQUAL{classind_Invisible_D_part1}=temp;
temp=allQUAL{classind_Invisible_S_part1}; temp(1,:)=temp(1,:)/FoVsize_Invisible_S_part1; allQUAL{classind_Invisible_S_part1}=temp;

meanqual_Invisible_D_part2= mean(cell2mat(allQUAL(classind_Invisible_D_part2)),2); 
FoVsize_Invisible_D_part2=meanqual_Invisible_D_part2(2,1); 
meanweightHQ_Invisible_D_part2=meanqual_Invisible_D_part2(3,1);
meanweightLQ_Invisible_D_part2=meanqual_Invisible_D_part2(4,1);
bwtocut=1/10^6*(time_end-time_start)*(FoVsize_Invisible_D_part2-FoVsize_Invisible_S_part2)*(meanweightHQ_Invisible_D_part2-meanweightLQ_Invisible_D_part2);
allBW{classind_Invisible_D_part2}=allBW{classind_Invisible_D_part2}-bwtocut;
allDBW{classind_Invisible_D_part2}=allDBW{classind_Invisible_D_part2}-bwtocut;
temp=allQUAL{classind_Invisible_D_part2}; temp(1,:)=temp(1,:)/FoVsize_Invisible_D_part2; allQUAL{classind_Invisible_D_part2}=temp;
temp=allQUAL{classind_Invisible_S_part2}; temp(1,:)=temp(1,:)/FoVsize_Invisible_S_part2; allQUAL{classind_Invisible_S_part2}=temp;

%% Final quantities
HeadMotion_Hotel_S_D_S = cell2mat(allHM([1 2])); %indexes_HOTEL_S_D_S
HeadMotion_Hotel_S_D_D = cell2mat(allHM([4 3])); %indexes_HOTEL_S_D_D
HeadMotion_Invisible_S_D_S = cell2mat(allHM([5 6])); %indexes_INVISIBLE_S_D_S
HeadMotion_Invisible_S_D_D = cell2mat(allHM([8 7])); %indexes_INVISIBLE_S_D_D

Bandwidth_Hotel_S_D_S = cell2mat(allBW([1 2]));
Bandwidth_Hotel_S_D_D = cell2mat(allBW([4 3]));
Bandwidth_Invisible_S_D_S = cell2mat(allBW([5 6]));
Bandwidth_Invisible_S_D_D = cell2mat(allBW([8 7]));

Replacements_Hotel_S_D_S = cell2mat(allRPL([1 2]));
Replacements_Hotel_S_D_D = cell2mat(allRPL([4 3]));
Replacements_Invisible_S_D_S = cell2mat(allRPL([5 6]));
Replacements_Invisible_S_D_D = cell2mat(allRPL([8 7]));

DisplayedBandwidth_Hotel_S_D_S = cell2mat(allDBW([1 2]));
DisplayedBandwidth_Hotel_S_D_D = cell2mat(allDBW([4 3]));
DisplayedBandwidth_Invisible_S_D_S = cell2mat(allDBW([5 6]));
DisplayedBandwidth_Invisible_S_D_D = cell2mat(allDBW([8 7]));

WastedBandwidth_Hotel_S_D_S = Bandwidth_Hotel_S_D_S-DisplayedBandwidth_Hotel_S_D_S;
WastedBandwidth_Hotel_S_D_D = Bandwidth_Hotel_S_D_D-DisplayedBandwidth_Hotel_S_D_D;
WastedBandwidth_Invisible_S_D_S = Bandwidth_Invisible_S_D_S-DisplayedBandwidth_Invisible_S_D_S;
WastedBandwidth_Invisible_S_D_D = Bandwidth_Invisible_S_D_D-DisplayedBandwidth_Invisible_S_D_D;

Quality_Hotel_S_D_S = cell2mat(allQUAL([1 2])); % (4 rows)
Quality_Hotel_S_D_D = cell2mat(allQUAL([4 3]));
Quality_Invisible_S_D_S = cell2mat(allQUAL([5 6]));
Quality_Invisible_S_D_D = cell2mat(allQUAL([8 7]));

%% Getting the t-values and p-values of the paired t-test
samples=HeadMotion_Hotel_S_D_S-HeadMotion_Hotel_S_D_D;
tvalue=mean(samples)/(std(samples)/sqrt(length(samples))); pvalue=1-tcdf(tvalue,length(samples)-1); tpvalues=[tvalue,pvalue];
samples=HeadMotion_Invisible_S_D_S-HeadMotion_Invisible_S_D_D;
tvalue=mean(samples)/(std(samples)/sqrt(length(samples))); pvalue=1-tcdf(tvalue,length(samples)-1); tpvalues=[tpvalues;[tvalue,pvalue]];

samples=Replacements_Hotel_S_D_S-Replacements_Hotel_S_D_D;
tvalue=mean(samples)/(std(samples)/sqrt(length(samples))); pvalue=1-tcdf(tvalue,length(samples)-1); tpvalues=[tpvalues;[tvalue,pvalue]];
samples=Replacements_Invisible_S_D_S-Replacements_Invisible_S_D_D;
tvalue=mean(samples)/(std(samples)/sqrt(length(samples))); pvalue=1-tcdf(tvalue,length(samples)-1); tpvalues=[tpvalues;[tvalue,pvalue]];

samples=Bandwidth_Hotel_S_D_S-Bandwidth_Hotel_S_D_D;
tvalue=mean(samples)/(std(samples)/sqrt(length(samples))); pvalue=1-tcdf(tvalue,length(samples)-1); tpvalues=[tpvalues;[tvalue,pvalue]];
samples=Bandwidth_Invisible_S_D_S-Bandwidth_Invisible_S_D_D;
tvalue=mean(samples)/(std(samples)/sqrt(length(samples))); pvalue=1-tcdf(tvalue,length(samples)-1); tpvalues=[tpvalues;[tvalue,pvalue]];

samples=WastedBandwidth_Hotel_S_D_S-WastedBandwidth_Hotel_S_D_D;
tvalue=mean(samples)/(std(samples)/sqrt(length(samples))); pvalue=1-tcdf(tvalue,length(samples)-1); tpvalues=[tpvalues;[tvalue,pvalue]];
samples=WastedBandwidth_Invisible_S_D_S-WastedBandwidth_Invisible_S_D_D;
tvalue=mean(samples)/(std(samples)/sqrt(length(samples))); pvalue=1-tcdf(tvalue,length(samples)-1); tpvalues=[tpvalues;[tvalue,pvalue]];

samples=DisplayedBandwidth_Hotel_S_D_S-DisplayedBandwidth_Hotel_S_D_D;
tvalue=mean(samples)/(std(samples)/sqrt(length(samples))); pvalue=1-tcdf(tvalue,length(samples)-1); tpvalues=[tpvalues;[tvalue,pvalue]];
samples=DisplayedBandwidth_Invisible_S_D_S-DisplayedBandwidth_Invisible_S_D_D;
tvalue=mean(samples)/(std(samples)/sqrt(length(samples))); pvalue=1-tcdf(tvalue,length(samples)-1); tpvalues=[tpvalues;[tvalue,pvalue]];

samples=Quality_Hotel_S_D_S(1,:)-Quality_Hotel_S_D_D(1,:);
tvalue=mean(samples)/(std(samples)/sqrt(length(samples))); pvalue=tcdf(tvalue,length(samples)-1); tpvalues=[tpvalues;[tvalue,pvalue]];
samples=Quality_Invisible_S_D_S(1,:)-Quality_Invisible_S_D_D(1,:);
tvalue=mean(samples)/(std(samples)/sqrt(length(samples))); pvalue=tcdf(tvalue,length(samples)-1); tpvalues=[tpvalues;[tvalue,pvalue]];

%% PLOTS
colors22 = [0 0 1; 0 0 1; 1 0 0;1 0 0];
colors11 = [0 0 1; 1 0 0];
margin=0.08;

%% Diff in head motion over editings
%%{
figsub1=figure('units','normalized','outerposition',[0 0 1 1])
i=1;
h=subplot('Position',[mod(i-1,3)/3 1-ceil(i/3)/3 1/3-margin 1/3-margin]);

boxplot([(HeadMotion_Hotel_S_D_S-HeadMotion_Hotel_S_D_D)'./HeadMotion_Hotel_S_D_S';...
(HeadMotion_Invisible_S_D_S-HeadMotion_Invisible_S_D_D)'./HeadMotion_Invisible_S_D_S'],...
[repmat('Hotel S-D    ',length(HeadMotion_Hotel_S_D_S),1);repmat('Invisible S-D',length(HeadMotion_Invisible_S_D_S),1)],...
'Colors' , colors11);
set(gca,'FontSize',12);
ax=ancestor(h,'axes');
yrule=ax.YAxis;
yrule.FontSize=16;
ylabel('relative difference','FontSize',18)
title('Head motion (diff.)','FontSize',20)
%%}

%% Diff in replacements over editings
%%{
figure(figsub1)
i=2;
h=subplot('Position',[mod(i-1,3)/3 1-ceil(i/3)/3 1/3-margin 1/3-margin]);

boxplot([(Replacements_Hotel_S_D_S-Replacements_Hotel_S_D_D)'./Replacements_Hotel_S_D_S';...
(Replacements_Invisible_S_D_S-Replacements_Invisible_S_D_D)'./Replacements_Invisible_S_D_S'],...
[repmat('Hotel S-D    ',length(HeadMotion_Hotel_S_D_S),1);repmat('Invisible S-D',length(HeadMotion_Invisible_S_D_S),1)],...
'Colors' , colors11);
set(gca,'FontSize',12);
ax=ancestor(h,'axes');
yrule=ax.YAxis;
yrule.FontSize=16;
ylabel('relative difference','FontSize',18)
title('Replacements (diff.)','FontSize',20)
%%}

%% Diff in total bw over editings
%%{
figure(figsub1)
i=4;
h=subplot('Position',[mod(i-1,3)/3 1-ceil(i/3)/3 1/3-margin 1/3-margin]);

boxplot([(Bandwidth_Hotel_S_D_S-Bandwidth_Hotel_S_D_D)'./Bandwidth_Hotel_S_D_S';...
(Bandwidth_Invisible_S_D_S-Bandwidth_Invisible_S_D_D)'./Bandwidth_Invisible_S_D_S'],...
[repmat('Hotel S-D    ',length(HeadMotion_Hotel_S_D_S),1);repmat('Invisible S-D',length(HeadMotion_Invisible_S_D_S),1)],...
'Colors' , colors11);
set(gca,'FontSize',12);
ax=ancestor(h,'axes');
yrule=ax.YAxis;
yrule.FontSize=16;
ylabel('relative difference','FontSize',18)
title('Total bandwidth (diff.)','FontSize',20)
%}

%% Diff in wasted bw over editings
%%{
figure(figsub1)
i=5;
h=subplot('Position',[mod(i-1,3)/3 1-ceil(i/3)/3 1/3-margin 1/3-margin]);

boxplot([(WastedBandwidth_Hotel_S_D_S-WastedBandwidth_Hotel_S_D_D)'./WastedBandwidth_Hotel_S_D_S';...
(WastedBandwidth_Invisible_S_D_S-WastedBandwidth_Invisible_S_D_D)'./WastedBandwidth_Invisible_S_D_S'],...
[repmat('Hotel S-D    ',length(HeadMotion_Hotel_S_D_S),1);repmat('Invisible S-D',length(HeadMotion_Invisible_S_D_S),1)],...
'Colors' , colors11);
set(gca,'FontSize',12);
ax=ancestor(h,'axes');
yrule=ax.YAxis;
yrule.FontSize=16;
ylabel('relative difference','FontSize',18)
title('Wasted bandwidth (diff.)','FontSize',20)
%}

%%%% Displayed
%% Diff in displayed bw over editings
%%{
figure(figsub1)
i=6;
h=subplot('Position',[mod(i-1,3)/3 1-ceil(i/3)/3 1/3-margin 1/3-margin]);

boxplot([(DisplayedBandwidth_Hotel_S_D_S-DisplayedBandwidth_Hotel_S_D_D)'./DisplayedBandwidth_Hotel_S_D_S';(DisplayedBandwidth_Invisible_S_D_S-DisplayedBandwidth_Invisible_S_D_D)'./DisplayedBandwidth_Invisible_S_D_S'],...
[repmat('Hotel S-D    ',length(HeadMotion_Hotel_S_D_S),1);repmat('Invisible S-D',length(HeadMotion_Invisible_S_D_S),1)],...
'Colors' , colors11);
set(gca,'FontSize',12);
ax=ancestor(h,'axes');
yrule=ax.YAxis;
yrule.FontSize=16;
ylabel('relative difference','FontSize',18)
title('Displayed bandwidth (diff.)','FontSize',20)
%}

%% Total bw over the editings
%%{
figure(figsub1)
i=7;
h=subplot('Position',[mod(i-1,3)/3 1-ceil(i/3)/3 1/3-margin 1/3-margin]);

boxplot([Bandwidth_Hotel_S_D_S';Bandwidth_Hotel_S_D_D';...
Bandwidth_Invisible_S_D_S';Bandwidth_Invisible_S_D_D'],...
[repmat('Hotel S    ',length(HeadMotion_Hotel_S_D_S),1);repmat('Hotel D    ',length(HeadMotion_Hotel_S_D_D),1);repmat('Invisible S',length(HeadMotion_Invisible_S_D_S),1);;repmat('Invisible D',length(HeadMotion_Invisible_S_D_D),1)],...
'Colors' , colors22);
set(gca,'FontSize',12);
ax=ancestor(h,'axes');
yrule=ax.YAxis;
yrule.FontSize=16;
ylabel('bandwidth (MB)','FontSize',18)
title('Total bandwidth','FontSize',20)
%%}
%% Wasted bw over the editings
%%{
figure(figsub1)
i=8;
h=subplot('Position',[mod(i-1,3)/3 1-ceil(i/3)/3 1/3-margin 1/3-margin]);

boxplot([WastedBandwidth_Hotel_S_D_S';WastedBandwidth_Hotel_S_D_D';...
WastedBandwidth_Invisible_S_D_S';WastedBandwidth_Invisible_S_D_D'],...
[repmat('Hotel S    ',length(HeadMotion_Hotel_S_D_S),1);repmat('Hotel D    ',length(HeadMotion_Hotel_S_D_D),1);repmat('Invisible S',length(HeadMotion_Invisible_S_D_S),1);;repmat('Invisible D',length(HeadMotion_Invisible_S_D_D),1)],...
'Colors' , colors22);
set(gca,'FontSize',12);
ax=ancestor(h,'axes');
yrule=ax.YAxis;
yrule.FontSize=16;
ylabel('bandwidth (MB)','FontSize',18)
title('Wasted bandwidth','FontSize',20)
%%}
%% Displayed bw over the editings
%%{
figure(figsub1)
i=9;
h=subplot('Position',[mod(i-1,3)/3 1-ceil(i/3)/3 1/3-margin 1/3-margin]);

boxplot([DisplayedBandwidth_Hotel_S_D_S';DisplayedBandwidth_Hotel_S_D_D';...
DisplayedBandwidth_Invisible_S_D_S';DisplayedBandwidth_Invisible_S_D_D'],...
[repmat('Hotel S    ',length(HeadMotion_Hotel_S_D_S),1);repmat('Hotel D    ',length(HeadMotion_Hotel_S_D_D),1);repmat('Invisible S',length(HeadMotion_Invisible_S_D_S),1);;repmat('Invisible D',length(HeadMotion_Invisible_S_D_D),1)],...
'Colors' , colors22);
set(gca,'FontSize',12);
ax=ancestor(h,'axes');
yrule=ax.YAxis;
yrule.FontSize=16;
ylabel('bandwidth (MB)','FontSize',18)
title('Displayed bandwidth','FontSize',20)
%%}
%% FoVQuality over the editings
%%{
figure(figsub1)
i=3;
h=subplot('Position',[mod(i-1,3)/3 1-ceil(i/3)/3 1/3-margin 1/3-margin]);

boxplot([Quality_Hotel_S_D_S(1,:)';Quality_Hotel_S_D_D(1,:)';...
Quality_Invisible_S_D_S(1,:)';Quality_Invisible_S_D_D(1,:)'],...
[repmat('Hotel S    ',length(HeadMotion_Hotel_S_D_S),1);repmat('Hotel D    ',length(HeadMotion_Hotel_S_D_D),1);repmat('Invisible S',length(HeadMotion_Invisible_S_D_S),1);;repmat('Invisible D',length(HeadMotion_Invisible_S_D_D),1)],...
'Colors' , colors22);
set(gca,'FontSize',12);
ax=ancestor(h,'axes');
yrule=ax.YAxis;
yrule.FontSize=16;
ylabel('relative quality','FontSize',18)
title('FoV quality','FontSize',20)
%%}
