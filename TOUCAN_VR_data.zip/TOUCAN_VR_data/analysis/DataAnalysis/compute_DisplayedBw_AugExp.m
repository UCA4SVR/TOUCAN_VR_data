function DisplayedBandwidth=compute_DisplayedBw_AugExp(tileQuality,content,editing)

if strcmp(content,'Hotel')&& (strcmp(editing,'RS')|strcmp(editing,'RD')),
    fileSizes = importdata('../../data_for_exp/file_sizes_AugExp/hotel_random_file_sizes_formated.csv', ',', 1);
elseif strcmp(content,'Invisible')&& (strcmp(editing,'RS')|strcmp(editing,'RD')),
    fileSizes = importdata('../../data_for_exp/file_sizes_AugExp/invisible_random_file_sizes_formated.csv', ',', 1);
elseif strcmp(content,'Hotel')&& (strcmp(editing,'S')|strcmp(editing,'D')),
    fileSizes = importdata('../../data_for_exp/file_sizes_AugExp/hotel_static_file_sizes_formated.csv', ',', 1);
elseif strcmp(content,'Invisible')&& (strcmp(editing,'S')|strcmp(editing,'D')),
    fileSizes = importdata('../../data_for_exp/file_sizes_AugExp/invisible_static_file_sizes_formated.csv', ',', 1);
else
    error('wrong content or editing acronym');
end;
fileSizes = fileSizes.data;

currentSegment = tileQuality(1,3);
currentQualities = tileQuality(tileQuality(:,3)==currentSegment, [2,6]);
currentQualities = sortrows(currentQualities);

displayed_bytes_per_seg=0;
while size(currentQualities,1) ~= 0,
    currentWeight = 0;
    for i = 1:9
        row = floor((i-1)/3);
        col = mod((i-1),3);
        currentFile = fileSizes(fileSizes(:,2)==currentSegment,1:end);
        currentFile = currentFile(currentFile(:,3)==col,1:end);
        currentFile = currentFile(currentFile(:,4)==row,1:end);
        currentFile = currentFile(currentFile(:,1)==currentQualities(i,2),1:end);
        currentWeight = currentWeight + currentFile(5);
    end
    displayed_bytes_per_seg(currentSegment) = currentWeight;
    
    currentSegment = currentSegment+1;
    currentQualities = tileQuality(tileQuality(:,3)==currentSegment, [2,6]);
    %%% to complete when pb with diff nb of segments per tile
    l=size(currentQualities,1);
    if l>0 && l<9,
        l=size(currentQualities,1); currentQualities(l+1:9,:)=[(setdiff(0:8,currentQualities(:,1)))',zeros(length(l:8),1)];
    end;
    %%%
    currentQualities = sortrows(currentQualities);
end
DisplayedBandwidth=sum(displayed_bytes_per_seg)/10^6;

end
