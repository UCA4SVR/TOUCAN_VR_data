clear
clc
close all

[ subjective_Hotel_S, subjective_Hotel_D, subjective_Invisible_S, subjective_Invisible_D,] = all_subjective_measures_OctExp( );

plotNames = {'Performance: task score', 'Satisfaction: detect rotation ','Satisfaction: overall quality',' SATISFACTION Different zones ', ...
    'SATISFACTION Quality changes ',' Satisfaction: immersiveness ',' Comfort: sickness', ...
    'Comfort: had to move too much' , 'Comfort: limited exploration'};

%% PLOTS
colors22 = [0 0 1; 0 0 1; 1 0 0;1 0 0];
margin=0.08;

figure('units','normalized','outerposition',[0 0 1 1])
i=1; j=i;
h=subplot('Position',[mod(j-1,3)/3 1-ceil(j/3)/3 1/3-margin 1/3-margin]);

boxplot([subjective_Hotel_S(:,i);subjective_Hotel_D(:,i);subjective_Invisible_S(:,i);subjective_Invisible_D(:,i)], ...
    [repmat('Hotel S    ',size(subjective_Hotel_S,1),1);repmat('Hotel D    ',size(subjective_Hotel_D,1),1);...
    repmat('Invisible S',size(subjective_Invisible_S,1),1);repmat('Invisible D',size(subjective_Invisible_D,1),1)],...
    'Colors' , colors22);
set(gca,'FontSize',12);
ax=ancestor(h,'axes');
yrule=ax.YAxis;
yrule.FontSize=16;
ylabel('MOS','FontSize',18)
title(plotNames{i},'FontSize',20)
yticks([1:5]);
ylim([0,5.5]);
i=2; j=5;
h=subplot('Position',[mod(j-1,3)/3 1-ceil(j/3)/3 1/3-margin 1/3-margin]);

boxplot([subjective_Hotel_S(:,i);subjective_Hotel_D(:,i);subjective_Invisible_S(:,i);subjective_Invisible_D(:,i)], ...
    [repmat('Hotel S    ',size(subjective_Hotel_S,1),1);repmat('Hotel D    ',size(subjective_Hotel_D,1),1);...
    repmat('Invisible S',size(subjective_Invisible_S,1),1);repmat('Invisible D',size(subjective_Invisible_D,1),1)],...
    'Colors' , colors22);

set(gca,'FontSize',12);
ax=ancestor(h,'axes');
yrule=ax.YAxis;
yrule.FontSize=16;
ylabel('MOS','FontSize',18)
title(plotNames{i},'FontSize',20)
yticks([1:5]);
ylim([0,5.5]);
i=3; j=4;
h=subplot('Position',[mod(j-1,3)/3 1-ceil(j/3)/3 1/3-margin 1/3-margin]);
boxplot([subjective_Hotel_S(:,i);subjective_Hotel_D(:,i);subjective_Invisible_S(:,i);subjective_Invisible_D(:,i)], ...
    [repmat('Hotel S    ',size(subjective_Hotel_S,1),1);repmat('Hotel D    ',size(subjective_Hotel_D,1),1);...
    repmat('Invisible S',size(subjective_Invisible_S,1),1);repmat('Invisible D',size(subjective_Invisible_D,1),1)],...
    'Colors' , colors22);
set(gca,'FontSize',12);
ax=ancestor(h,'axes');
yrule=ax.YAxis;
yrule.FontSize=16;
ylabel('MOS','FontSize',18)
title(plotNames{i},'FontSize',20)
yticks([1:5]);
ylim([0,5.5]);
for i = 6:9
    h=subplot('Position',[mod(i-1,3)/3 1-ceil(i/3)/3 1/3-margin 1/3-margin]);
    boxplot([subjective_Hotel_S(:,i);subjective_Hotel_D(:,i);subjective_Invisible_S(:,i);subjective_Invisible_D(:,i)], ...
        [repmat('Hotel S    ',size(subjective_Hotel_S,1),1);repmat('Hotel D    ',size(subjective_Hotel_D,1),1);...
        repmat('Invisible S',size(subjective_Invisible_S,1),1);repmat('Invisible D',size(subjective_Invisible_D,1),1)],...
        'Colors' , colors22);
    set(gca,'FontSize',12);
    ax=ancestor(h,'axes');
    yrule=ax.YAxis;
    yrule.FontSize=16;
    ylabel('MOS','FontSize',18)
    title(plotNames{i},'FontSize',20)
    yticks([1:5]);
    ylim([0,5.5]);
end

