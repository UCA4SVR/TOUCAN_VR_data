function [subjective_Hotel_S,subjective_Hotel_D,subjective_Invisible_S,subjective_Invisible_D]= all_subjective_measures_OctExp()
%ALL_SUBJECTIVE_MEASURES outputs the subjective measures in separate
% Each matrix contains the subjective information for the requested content
% and editing, one line per user and the columns set in the order mentioned
% below:
%   PERFORMANCE SCORE | SATISFACTION QUALITY | SATISFACTION Different zones |
%   SATISFACTION Quality changes | SATISFACTION immersiveness | COMFORT Discomfort | 
%   COMFORT Move too much | COMFORT Limitation

contents = ['Hotel', 'Invisible'];
editings = ['S','D'];
[num, txt, data] = xlsread('../../data_from_exp/LogFiles_OctExp/QoE_OctExp.xlsx');
txt = string(txt(:,[1:3]));

d_rows = data(txt(:,3)=='D', :);
s_rows = data(txt(:,3)=='S', :);
d_txt = string(d_rows(:,[1:3]));
s_txt = string(s_rows(:,[1:3]));

subjective_Hotel_D = cell2mat(d_rows(d_txt(:,2)=='Hotel',[4:12]));
subjective_Hotel_S = cell2mat(s_rows(s_txt(:,2)=='Hotel',[4:12]));

subjective_Invisible_D = cell2mat(d_rows(d_txt(:,2)=='Invisible',[4:12]));
subjective_Invisible_S = cell2mat(s_rows(s_txt(:,2)=='Invisible',[4:12]));

end

