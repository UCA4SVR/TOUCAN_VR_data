from HeadMotion import HeadMotion
import matplotlib.pyplot as plt
import utils

import sys, getopt

def main(argv):
    try:
       opts, args = getopt.getopt(argv,"hw:i:u:e:d:",["warp","hmfile","user","editing", "dicontinuity"])
    except getopt.GetoptError:
       print('test_Nov.py -i <hmfile> -u <userid> -e <editing>')
       sys.exit(2)
    warp_precision=10
    discontinuity_precision = 300
    for opt, arg in opts:
       if opt == '-h':
          print('headprocess_AugExp.py -i <hmfile> -u <userid> -e <editing>')
          sys.exit()
       elif opt in ("-w", "--warp"):
          warp_precision = int(arg)
       elif opt in ("-i", "--hmfile"):
          hmfile = arg
       elif opt in ("-u", "--user"):
          user = arg
       elif opt in ("-e", "--editing"):
          editing = arg
       elif opt in ("-d", "--discontinuity"):
          discontinuity_precision = int(arg)
    print('user is ', user)
    print('editing is ', editing)

    head_motion_path = hmfile
    print('wp= ', warp_precision)
    print('d= ', discontinuity_precision)

    hm = HeadMotion(head_motion_path,
                    step=3, discontinuity_precision=discontinuity_precision, warp_precision=warp_precision)
    hm.time_reference = utils.set_common_origin(hm.time)
    hm.compute_average_velocity()
    hm.time[:] = [x/1000 for x in hm.time]
    
    # saving to mat files
    filepath="../../data_from_exp/LogFiles_AugExp/User "
    hm.export_to_matlab(filepath+user+"/user"+user+"_"+editing+"_hm.mat", user, editing)
    
if __name__ == "__main__":
    main(sys.argv[1:])

