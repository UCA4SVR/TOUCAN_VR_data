# Utils module containing the functions to read the dsv files

import pandas


def parse_csv_to_array_head_motion(filename, columnNames):
    return pandas.read_csv(filename, names=columnNames)


def set_common_origin(*args):
    minimum = float('inf')
    for i in range(0,len(args)):
        if len(args[i]) != 0:
            current = min(args[i])
            if current < minimum:
                minimum = current
    for i in range(0, len(args)):
        args[i][:] = [x - minimum for x in args[i]]
    return minimum
