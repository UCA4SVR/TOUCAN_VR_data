import pandas
import numpy as np
import scipy.io
import matplotlib.ticker as ticker
import matplotlib.pyplot as plt


class HeadMotion:
    """Class to handle the head motion data loading and formating.
    The angles are logged between -180 and 180. For the analysis, it is
    easier to work with continuous functions. Therefore a regularization is applied to the raw data.
    It checks if the function is continuous at a certain precision (discontinuityPrecision).
    If it is not, it checks if it is because of a warp between 180 and -180 using the warpPrecision.
    If it is because of a warp, it applies a regularization offset and if not, it regiters the data.
    By default it computes the position and velocity of the user along the Y and X axis for each sample
    logged, but a step can be used to register only one over step samples with the step parameter."""

    FONT_SIZE = 14

    def __init__(self, filename, step=1, discontinuity_precision=300, warp_precision=10):
        column_names = ['system_timestamp', 'video_time', 'x_euler_angle', 'y_euler_angle', 'z_euler_angle', 'x_angle',
                        'y_angle']
        data = pandas.read_csv(filename, names=column_names)
        self.system_timestamp = data.system_timestamp.tolist()
        self.video_time = data.video_time.tolist()
        self.euler_x = data.x_euler_angle.tolist()
        self.euler_y = data.y_euler_angle.tolist()
        self.euler_z = data.z_euler_angle.tolist()
        self.angle_x = data.x_angle.tolist()
        self.angle_y = data.y_angle.tolist()
        self.__prepare_motion_and_velocity(step, discontinuity_precision, warp_precision)

    def __prepare_motion_and_velocity(self, step, discontinuity_precision, warp_precision):

        """Handle cases with 0 or 1 sample only"""
        if len(self.system_timestamp) == 1:
            return [self.system_timestamp, [0], [0], self.angle_x, self.angle_y]

        if len(self.system_timestamp) == 0:
            return [[], [], [], [], []]

        """From 2 samples real stuff happen. Position in the log file are stored between -180 and 180.
           Therefore there are discontinuities when going in the same direction and crossing the -180, 180 point.
           To have a continuous function, a regularization is done by checking the continuity of the function
           and applying a corrective offset when needed."""
        # The offset is initialized to 0
        offset_x = 0
        offset_y = 0
        # Time is initialized with the 2 first values, initial position is registered and initial velocity is null
        self.time = [self.system_timestamp[0], self.system_timestamp[1]]
        self.position_x = [self.angle_x[0]]
        self.position_y = [self.angle_y[0]]
        self.velocity_x = [float(0)]
        self.velocity_y = [float(0)]
        # Check wether a discontinuity happened between the first and second samples
        # Can't use the velocity there to approximate the function so using the sign change and a high threshold
        if self.angle_x[1] * self.angle_x[0] < 0 and abs(self.angle_x[1]) > 180:
            """We had a discontinuity between the first and the second samples"""
            if self.position_x[0] > 0:
                offset_x = 360
            else:
                offset_x = -360
        self.position_x.append(self.angle_x[1] + offset_x)
        self.velocity_x.append((self.position_x[1] - self.position_x[0]) * 1000 / (self.time[1] - self.time[0]))

        # Same for Y
        if self.angle_y[1] * self.angle_y[0] < 0 and abs(self.angle_y[1]) > 180:
            """We had a discontinuity between the first and the second samples"""
            if self.position_y[0] > 0:
                offset_y = 360
            else:
                offset_y = -360
        self.position_y.append(self.angle_y[1] + offset_y)
        self.velocity_y.append((self.position_y[1] - self.position_y[0]) * 1000 / (self.time[1] - self.time[0]))

        # From now we can do a loop
        j = 2
        previous_i = 1
        for i in range(2, len(self.system_timestamp), step):
            # First append the time and compute the time delta to the new sample
            self.time.append(self.system_timestamp[i])
            delta_t = (self.time[j] - self.time[j - 1]) / 1000
            # If the approximation of the angle function using a linear interpolation with the velocity is not precise
            # enough, we have a discontinuity and must update the threshold base on the velocity sign.
            approximation = self.angle_x[i] - (self.angle_x[previous_i] + delta_t * self.velocity_x[j - 1])
            if -discontinuity_precision >= approximation or approximation >= discontinuity_precision:
                if abs(abs(self.angle_x[previous_i]) - 180) < warp_precision:
                    if self.angle_x[i] < 0 and self.angle_x[previous_i] > 0:
                        offset_x = offset_x + 360
                    else:
                        offset_x = offset_x - 360
            # Then the position can be recorded using the new corrective offset and the velocity can be computed.
            self.position_x.append(self.angle_x[i] + offset_x)
            self.velocity_x.append((self.position_x[j] - self.position_x[j - 1]) / delta_t)

            # Same for Y
            approximation = self.angle_y[i] - (self.angle_y[previous_i] + delta_t * self.velocity_y[j - 1])
            if -discontinuity_precision >= approximation or approximation >= discontinuity_precision:
                if abs(abs(self.angle_y[previous_i]) - 180) < warp_precision:
                    if self.angle_y[i] < 0 and self.angle_y[previous_i] > 0:
                        offset_y = offset_y + 360
                    else:
                        offset_y = offset_y - 360
            self.position_y.append(self.angle_y[i] + offset_y)
            self.velocity_y.append((self.position_y[j] - self.position_y[j - 1]) / delta_t)
            j = j + 1
            previous_i = i

    def compute_average_velocity(self):
        current_numerator = 0
        self.average_velocity = [float(0)]
        for i in range(1, len(self.time)):
                current_numerator += np.sqrt(np.square(self.velocity_y[i]) + np.square(self.velocity_x[i])) * (self.time[i] - self.time[i-1]) / 1000
                self.average_velocity.append(1000 * current_numerator / self.time[i])


    def render_data_head_motion_figure(self):
        figure_head_motion, axes_head_motion = plt.subplots(2, sharex='row', sharey='col')
        plots_head_motion = []
        array = [self.system_timestamp, self.velocity_x, self.velocity_y, self.position_x, self.position_y]
        x = array[0]
        angular_x = np.squeeze(np.asarray(array[1]))
        angular_y = np.squeeze(np.asarray(array[2]))
        angles_x = np.squeeze(np.asarray(array[3]))
        angles_y = np.squeeze(np.asarray(array[4]))
        scale_x = 1
        ticks_x = ticker.FuncFormatter(lambda item, pos: '{0:g}'.format(item / scale_x))  # ms/1e3 -> s
        axes_head_motion[1].xaxis.set_major_formatter(ticks_x)
        figure_head_motion.subplots_adjust(hspace=.0)
        axis_head_motion_0_theta_x = axes_head_motion[0].twinx()
        position_head_motion = axis_head_motion_0_theta_x.plot(x, angles_x, color="red", label='Position')
        plots_head_motion.extend(position_head_motion)
        axis_head_motion_0_theta_x.set_ylabel('Position X (°)')
        axis_head_motion_0_theta_x.set_yticks([-180, 0, 180])
        angular_velocity_head_motion = axes_head_motion[0].plot(x, angular_x, label='Angular Velocity')
        plots_head_motion.extend(angular_velocity_head_motion)
        axes_head_motion[0].set_ylabel('on x-axis (°/s)')
        axes_head_motion[0].yaxis.set_tick_params(labelsize=self.FONT_SIZE)
        axes_head_motion[1].set_ylabel('Angular velocity on y-axis YAW (°/s)')
        axes_head_motion[1].set_xlabel('Time (s)')
        axes_head_motion_1_theta_y = axes_head_motion[1].twinx()
        axes_head_motion_1_theta_y.plot(x, angles_y, color="red")
        axes_head_motion_1_theta_y.set_ylabel('Position Y (°)')
        axes_head_motion_1_theta_y.set_yticks([-180, 0, 180])
        axes_head_motion[1].plot(x, angular_y)
        return

    def export_to_matlab(self, file_path, user, editing):
        scipy.io.savemat(file_path, {'headMotion_videoTime' : self.video_time, #"user"+user+"_"+editing+"_"+
                                     'headMotion_time': self.time, #"user"+user+"_"+editing+"_"+
                                     'headMotion_positionX': self.position_x, #"user"+user+"_"+editing+"_"+
                                     'headMotion_positionY': self.position_y, #"user"+user+"_"+editing+"_"+
                                     'headMotion_velocityX': self.velocity_x, #"user"+user+"_"+editing+"_"+
                                     'headMotion_velocityY': self.velocity_y, #"user"+user+"_"+editing+"_"+
                                     'headMotion_meanVelocity' : self.average_velocity, #"user"+user+"_"+editing+"_"+
                                     'headMotion_timeReference' : self.time_reference #"user"+user+"_"+editing+"_"+
                                     })
