The videos used for the experiments and described in the MMSys 2017 article are available at:
https://mycore.core-cloud.net/index.php/s/DH1F1vpp6nDWDYh
